/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Classroom, SessionAttendance, ViewTab } from './types/attendance';
import {
  loadClasses,
  saveClasses,
  loadSessions,
  saveSession,
  deleteSession,
  loadSettings,
  saveSettings,
  AppSettings,
} from './utils/storage';
import { TopNav } from './components/TopNav';
import { MarkAttendanceView } from './components/MarkAttendanceView';
import { HistoryHeatmapView } from './components/HistoryHeatmapView';
import { StudentAnalyticsView } from './components/StudentAnalyticsView';
import { ReportsExportView } from './components/ReportsExportView';
import { ClassRosterView } from './components/ClassRosterView';
import { Logo } from './components/Logo';
import { LogoIntroAnimation } from './components/LogoIntroAnimation';

export default function App() {
  const [classes, setClasses] = useState<Classroom[]>(() => loadClasses());
  const [sessions, setSessions] = useState<SessionAttendance[]>(() => loadSessions(loadClasses()));
  const [selectedClass, setSelectedClass] = useState<Classroom>(() => {
    const list = loadClasses();
    return list[0] || ({} as Classroom);
  });
  const [currentTab, setCurrentTab] = useState<ViewTab>('mark');
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  // Show the logo forge & glass shatter representation whenever app opens
  const [showIntro, setShowIntro] = useState<boolean>(true);

  // Keep selectedClass in sync with classes array if modified
  useEffect(() => {
    const found = classes.find((c) => c.id === selectedClass.id);
    if (found) {
      setSelectedClass(found);
    } else if (classes.length > 0) {
      setSelectedClass(classes[0]);
    }
  }, [classes, selectedClass.id]);

  // Handle saving an attendance session
  const handleSaveSession = (session: SessionAttendance) => {
    const updated = saveSession(session);
    setSessions(updated);
  };

  // Handle deleting a session
  const handleDeleteSession = (sessionId: string) => {
    const updated = deleteSession(sessionId);
    setSessions(updated);
  };

  // Handle updating an existing classroom
  const handleUpdateClassroom = (updated: Classroom) => {
    const updatedList = classes.map((c) => (c.id === updated.id ? updated : c));
    setClasses(updatedList);
    saveClasses(updatedList);
    setSelectedClass(updated);
  };

  // Handle creating a new classroom
  const handleCreateClassroom = (newClass: Classroom) => {
    const updatedList = [...classes, newClass];
    setClasses(updatedList);
    saveClasses(updatedList);
    setSelectedClass(newClass);
  };

  // Handle data reset
  const handleDataReset = () => {
    const freshClasses = loadClasses();
    const freshSessions = loadSessions(freshClasses);
    setClasses(freshClasses);
    setSessions(freshSessions);
    setSelectedClass(freshClasses[0]);
  };

  // Toggle sound
  const handleToggleSound = () => {
    const updated = { ...settings, soundEnabled: !settings.soundEnabled };
    setSettings(updated);
    saveSettings(updated);
  };

  // Cycle through logo variants
  const handleCycleLogo = () => {
    const variants: Array<'official' | 'monogram' | 'shield' | 'folio'> = ['official', 'monogram', 'shield', 'folio'];
    const current = settings.logoStyle || 'official';
    const nextIdx = (variants.indexOf(current) + 1) % variants.length;
    const nextVariant = variants[nextIdx];
    const updated = { ...settings, logoStyle: nextVariant };
    setSettings(updated);
    saveSettings(updated);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Opening Representation & Logo Forging Animation */}
      {showIntro && (
        <LogoIntroAnimation
          onComplete={() => setShowIntro(false)}
          soundEnabled={settings.soundEnabled}
          onToggleSound={handleToggleSound}
        />
      )}

      {/* Top Navigation Bar with strict 3-zone contract */}
      <TopNav
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        selectedClass={selectedClass}
        classes={classes}
        onSelectClass={setSelectedClass}
        soundEnabled={settings.soundEnabled}
        onToggleSound={handleToggleSound}
        logoVariant={settings.logoStyle || 'official'}
        onCycleLogo={handleCycleLogo}
        onPlayLogoIntro={() => setShowIntro(true)}
      />

      {/* Main Workspace Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentTab === 'mark' && (
          <MarkAttendanceView
            classroom={selectedClass}
            sessions={sessions}
            onSaveSession={handleSaveSession}
            soundEnabled={settings.soundEnabled}
            onUpdateClassroom={handleUpdateClassroom}
          />
        )}

        {currentTab === 'history' && (
          <HistoryHeatmapView
            classroom={selectedClass}
            sessions={sessions}
            onSelectSessionToEdit={(session) => {
              setCurrentTab('mark');
            }}
            onDeleteSession={handleDeleteSession}
            soundEnabled={settings.soundEnabled}
          />
        )}

        {currentTab === 'analytics' && (
          <StudentAnalyticsView
            classroom={selectedClass}
            sessions={sessions}
            soundEnabled={settings.soundEnabled}
            onUpdateClassroom={handleUpdateClassroom}
          />
        )}

        {currentTab === 'reports' && (
          <ReportsExportView
            classroom={selectedClass}
            sessions={sessions}
            onDataReset={handleDataReset}
            soundEnabled={settings.soundEnabled}
          />
        )}

        {currentTab === 'classes' && (
          <ClassRosterView
            classroom={selectedClass}
            classes={classes}
            onSelectClass={setSelectedClass}
            onUpdateClassroom={handleUpdateClassroom}
            onCreateClassroom={handleCreateClassroom}
            soundEnabled={settings.soundEnabled}
            logoVariant={settings.logoStyle || 'official'}
            onPlayLogoIntro={() => setShowIntro(true)}
            onSelectLogoVariant={(v) => {
              const updated = { ...settings, logoStyle: v };
              setSettings(updated);
              saveSettings(updated);
            }}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-3">
            <Logo
              size="sm"
              variant={settings.logoStyle || 'official'}
              showTagline={false}
              soundEnabled={settings.soundEnabled}
              onClick={handleCycleLogo}
            />
            <span>·</span>
            <span>Digital Classroom Attendance & Register System</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setCurrentTab('mark')}
              className="hover:text-slate-800 transition-colors"
            >
              Take Roll Call
            </button>
            <button
              onClick={() => setCurrentTab('history')}
              className="hover:text-slate-800 transition-colors"
            >
              Calendar Heatmap
            </button>
            <button
              onClick={() => setCurrentTab('analytics')}
              className="hover:text-slate-800 transition-colors"
            >
              Student Insights
            </button>
            <button
              onClick={() => setCurrentTab('reports')}
              className="hover:text-slate-800 transition-colors"
            >
              Export CSV
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
