import React, { useState, useEffect } from 'react';
import { Student, SessionAttendance } from '../types/attendance';
import { calculateStudentStats } from '../utils/storage';
import {
  X,
  Phone,
  Mail,
  Flame,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock,
  FileText,
  Copy,
  Check,
  Edit2,
  Save,
  User,
  Camera,
  Image as ImageIcon,
} from 'lucide-react';
import { playSound } from '../utils/audio';
import { StudentAvatar, PRESET_AVATARS } from './StudentAvatar';

interface StudentDossierModalProps {
  student: Student | null;
  classId: string;
  sessions: SessionAttendance[];
  onClose: () => void;
  soundEnabled: boolean;
  onUpdateStudent?: (updated: Student) => void;
}

export const StudentDossierModal: React.FC<StudentDossierModalProps> = ({
  student,
  classId,
  sessions,
  onClose,
  soundEnabled,
  onUpdateStudent,
}) => {
  const [copied, setCopied] = useState(false);
  const [customAbsenceDate, setCustomAbsenceDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Partial<Student>>({});
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    if (student) {
      setEditForm({
        name: student.name,
        rollNo: student.rollNo,
        gender: student.gender,
        guardianName: student.guardianName,
        guardianPhone: student.guardianPhone,
        guardianEmail: student.guardianEmail,
        notes: student.notes,
        seatRow: student.seatRow,
        seatCol: student.seatCol,
        avatarColor: student.avatarColor,
      });
      setIsEditing(false);
    }
  }, [student]);

  if (!student) return null;

  const stats = calculateStudentStats(student, classId, sessions);

  // Generate parent notification text
  const parentNoticeText = `Dear ${student.guardianName || 'Parent / Guardian'},

This is an automated attendance notice from St. Peter's International Academy.
Please be informed that your child ${student.name} (Roll No: ${student.rollNo}) was recorded as ABSENT for classes on ${customAbsenceDate}.

Current Academic Attendance Rate: ${stats.attendanceRate}% (${stats.presentCount} present / ${stats.absentCount} absences).

If this absence is due to illness or pre-approved leave, kindly reply to this message or submit an excuse note to the academic office.

Sincerely,
Faculty Academic Office`;

  const handleCopyNotice = () => {
    navigator.clipboard.writeText(parentNoticeText);
    setCopied(true);
    playSound('click', soundEnabled);
    setTimeout(() => setCopied(false), 2200);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm.name || !editForm.rollNo) return;

    const updated: Student = {
      ...student,
      name: editForm.name.trim(),
      rollNo: editForm.rollNo.trim(),
      gender: editForm.gender || 'male',
      guardianName: editForm.guardianName?.trim() || '',
      guardianPhone: editForm.guardianPhone?.trim() || '',
      guardianEmail: editForm.guardianEmail?.trim() || '',
      notes: editForm.notes?.trim() || '',
      seatRow: editForm.seatRow ? Number(editForm.seatRow) : undefined,
      seatCol: editForm.seatCol ? Number(editForm.seatCol) : undefined,
      avatarColor: editForm.avatarColor || student.avatarColor,
      photoUrl: editForm.photoUrl,
    };

    if (onUpdateStudent) {
      onUpdateStudent(updated);
    }
    playSound('complete', soundEnabled);
    setIsEditing(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <StudentAvatar
              student={student}
              size="md"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">{student.name}</h3>
                <span className="font-mono text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded">
                  {student.rollNo}
                </span>
                {stats.isAtRisk && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded">
                    <AlertTriangle className="w-3 h-3" />
                    At-Risk Attendance
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 capitalize">
                {student.gender} · Assigned Seat: {student.seatRow ? `Row ${student.seatRow}, Col ${student.seatCol}` : 'Unassigned'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onUpdateStudent && (
              <button
                onClick={() => {
                  playSound('click', soundEnabled);
                  setIsEditing((prev) => !prev);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                  isEditing
                    ? 'bg-slate-900 text-white'
                    : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                }`}
                title="Edit student name, roll number, or contact"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>{isEditing ? 'Cancel Edit' : 'Edit Info'}</span>
              </button>
            )}

            <button
              onClick={() => {
                playSound('click', soundEnabled);
                onClose();
              }}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {saveSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-2 animate-fade-in">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>Student details updated successfully!</span>
            </div>
          )}

          {/* Quick Edit Form View */}
          {isEditing ? (
            <form onSubmit={handleSaveEdit} className="p-5 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-sm border-b border-slate-200 pb-2">
                <User className="w-4 h-4 text-emerald-600" />
                <span>Edit Student Profile & Name</span>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-4 p-3 bg-white rounded-xl border border-slate-200">
                <StudentAvatar
                  student={{
                    name: editForm.name || student.name,
                    avatarColor: editForm.avatarColor || student.avatarColor,
                    photoUrl: editForm.photoUrl,
                  }}
                  size="xl"
                  editable
                  onPhotoChange={(url) => setEditForm({ ...editForm, photoUrl: url })}
                />
                <div className="space-y-1.5 text-center sm:text-left flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-xs text-slate-800">Student Photo / Avatar</span>
                    {editForm.photoUrl && (
                      <button
                        type="button"
                        onClick={() => setEditForm({ ...editForm, photoUrl: undefined })}
                        className="text-[11px] text-rose-600 font-semibold hover:underline"
                      >
                        Remove Photo
                      </button>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Hover avatar to upload photo, or click any preset below:
                  </p>
                  <div className="flex flex-wrap items-center gap-1.5 justify-center sm:justify-start">
                    {PRESET_AVATARS.map((presetUrl, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setEditForm({ ...editForm, photoUrl: presetUrl })}
                        className={`w-7 h-7 rounded-lg overflow-hidden border-2 transition-transform hover:scale-105 ${
                          editForm.photoUrl === presetUrl ? 'border-emerald-500 ring-2 ring-emerald-500/30' : 'border-slate-200'
                        }`}
                      >
                        <img src={presetUrl} alt="Preset avatar" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Full Student Name *</label>
                  <input
                    type="text"
                    required
                    value={editForm.name || ''}
                    onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Roll / ID Number *</label>
                  <input
                    type="text"
                    required
                    value={editForm.rollNo || ''}
                    onChange={(e) => setEditForm({ ...editForm, rollNo: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Gender</label>
                  <select
                    value={editForm.gender || 'male'}
                    onChange={(e) => setEditForm({ ...editForm, gender: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Guardian / Parent Name</label>
                  <input
                    type="text"
                    value={editForm.guardianName || ''}
                    onChange={(e) => setEditForm({ ...editForm, guardianName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Guardian Phone Number</label>
                  <input
                    type="text"
                    value={editForm.guardianPhone || ''}
                    onChange={(e) => setEditForm({ ...editForm, guardianPhone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Guardian Email Address</label>
                  <input
                    type="email"
                    value={editForm.guardianEmail || ''}
                    onChange={(e) => setEditForm({ ...editForm, guardianEmail: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Student Details</span>
                </button>
              </div>
            </form>
          ) : null}

          {/* Attendance Scorecards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 font-medium">Attendance Rate</span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className={`text-2xl font-bold font-mono tabular-nums ${stats.attendanceRate >= 85 ? 'text-emerald-600' : stats.attendanceRate >= 75 ? 'text-amber-600' : 'text-rose-600'}`}>
                  {stats.attendanceRate}%
                </span>
              </div>
              <div className="mt-1.5 w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                <div
                  className={`h-full rounded-full ${stats.attendanceRate >= 85 ? 'bg-emerald-500' : stats.attendanceRate >= 75 ? 'bg-amber-500' : 'bg-rose-500'}`}
                  style={{ width: `${stats.attendanceRate}%` }}
                />
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 font-medium">Present Days</span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
                  {stats.presentCount}
                </span>
                <span className="text-xs text-slate-400">/ {stats.totalSessions}</span>
              </div>
              <span className="text-[11px] text-emerald-600 font-medium flex items-center gap-1 mt-1">
                <CheckCircle2 className="w-3 h-3" /> Logged sessions
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 font-medium">Total Absences</span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono tabular-nums text-rose-600">
                  {stats.absentCount}
                </span>
                <span className="text-xs text-slate-400">({stats.lateCount} Late)</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">
                {stats.excusedCount} Excused leaves
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 font-medium">Active Streak</span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono tabular-nums text-indigo-600">
                  {stats.streak}
                </span>
                <span className="text-xs text-slate-500">days</span>
              </div>
              <span className="text-[11px] text-indigo-600 font-medium flex items-center gap-1 mt-1">
                <Flame className="w-3.5 h-3.5 text-amber-500" /> Consecutive
              </span>
            </div>
          </div>

          {/* Guardian Contact Info */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
              Guardian & Emergency Contact
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="space-y-1">
                <p className="text-slate-500 font-medium">Guardian Name:</p>
                <p className="text-slate-900 font-semibold">{student.guardianName || 'Not specified'}</p>
              </div>
              <div className="space-y-1">
                <p className="text-slate-500 font-medium">Phone Number:</p>
                <a
                  href={`tel:${student.guardianPhone}`}
                  className="text-emerald-700 font-semibold hover:underline inline-flex items-center gap-1"
                >
                  <Phone className="w-3.5 h-3.5" /> {student.guardianPhone || 'N/A'}
                </a>
              </div>
              <div className="space-y-1 sm:col-span-2">
                <p className="text-slate-500 font-medium">Email Address:</p>
                <a
                  href={`mailto:${student.guardianEmail}`}
                  className="text-blue-700 font-semibold hover:underline inline-flex items-center gap-1"
                >
                  <Mail className="w-3.5 h-3.5" /> {student.guardianEmail || 'N/A'}
                </a>
              </div>
            </div>
          </div>

          {/* Parent Absence Notice Generator */}
          <div className="p-4 rounded-xl bg-indigo-50/50 border border-indigo-100">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-indigo-600" />
                <h4 className="text-xs font-bold text-indigo-900 uppercase tracking-wider">
                  Draft Parent Absence Notification
                </h4>
              </div>
              <button
                onClick={handleCopyNotice}
                className="px-2.5 py-1 text-xs font-semibold rounded-md bg-indigo-600 text-white hover:bg-indigo-700 transition-colors flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied to Clipboard!' : 'Copy Template'}</span>
              </button>
            </div>
            <textarea
              readOnly
              rows={4}
              value={parentNoticeText}
              className="w-full text-xs font-mono bg-white text-slate-700 p-2.5 rounded-lg border border-indigo-200 focus:outline-none resize-none"
            />
          </div>

          {/* Recent Attendance Timeline */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
              Recent Session Records ({stats.recentLogs.length} total)
            </h4>
            <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100">
              {stats.recentLogs.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-400">No session records yet</div>
              ) : (
                stats.recentLogs.slice(0, 15).map((log, i) => (
                  <div key={i} className="px-4 py-2 flex items-center justify-between text-xs hover:bg-slate-50">
                    <div className="flex items-center gap-2">
                      {log.status === 'present' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                      {log.status === 'absent' && <XCircle className="w-4 h-4 text-rose-600" />}
                      {log.status === 'late' && <Clock className="w-4 h-4 text-amber-600" />}
                      {log.status === 'excused' && <CheckCircle2 className="w-4 h-4 text-sky-600" />}
                      <span className="font-medium text-slate-900">{log.date}</span>
                      <span className="text-slate-400">· {log.period}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {log.note && <span className="text-[11px] text-slate-500 italic">"{log.note}"</span>}
                      <span
                        className={`font-semibold capitalize px-2 py-0.5 rounded text-[11px] ${
                          log.status === 'present'
                            ? 'text-emerald-700 bg-emerald-50'
                            : log.status === 'absent'
                            ? 'text-rose-700 bg-rose-50'
                            : log.status === 'late'
                            ? 'text-amber-700 bg-amber-50'
                            : 'text-sky-700 bg-sky-50'
                        }`}
                      >
                        {log.status}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 flex justify-end bg-slate-50">
          <button
            onClick={() => {
              playSound('click', soundEnabled);
              onClose();
            }}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100"
          >
            Close Dossier
          </button>
        </div>
      </div>
    </div>
  );
};
