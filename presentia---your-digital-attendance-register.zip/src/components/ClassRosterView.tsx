import React, { useState } from 'react';
import { Classroom, Student } from '../types/attendance';
import { playSound } from '../utils/audio';
import { Logo, LogoVariant } from './Logo';
import { StudentAvatar, PRESET_AVATARS } from './StudentAvatar';
import {
  Users,
  UserPlus,
  Plus,
  Trash2,
  Edit2,
  Building,
  GraduationCap,
  Sparkles,
  Check,
  X,
  Phone,
  Mail,
  Palette,
  Camera,
  ClipboardList,
  Sliders,
  ChevronUp,
  ChevronDown,
  Save,
  AlertTriangle,
  ArrowRight,
} from 'lucide-react';

interface ClassRosterViewProps {
  classroom: Classroom;
  classes: Classroom[];
  onSelectClass: (c: Classroom) => void;
  onUpdateClassroom: (updated: Classroom) => void;
  onCreateClassroom: (newClass: Classroom) => void;
  soundEnabled: boolean;
  logoVariant?: LogoVariant;
  onSelectLogoVariant?: (v: LogoVariant) => void;
  onPlayLogoIntro?: () => void;
}

export const ClassRosterView: React.FC<ClassRosterViewProps> = ({
  classroom,
  classes,
  onSelectClass,
  onUpdateClassroom,
  onCreateClassroom,
  soundEnabled,
  logoVariant = 'official',
  onSelectLogoVariant,
  onPlayLogoIntro,
}) => {
  // Modal states
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [showBulkImportModal, setShowBulkImportModal] = useState(false);
  const [showCreateClassModal, setShowCreateClassModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // Inline editing state for quick renaming: studentId -> string
  const [inlineEditId, setInlineEditId] = useState<string | null>(null);
  const [inlineNameVal, setInlineNameVal] = useState('');

  // Class strength adjustment state
  const [targetStrength, setTargetStrength] = useState<number>(classroom.students.length);
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);

  // Bulk import textarea state
  const [bulkText, setBulkText] = useState('');
  const [bulkMode, setBulkMode] = useState<'replace' | 'append'>('append');

  // Single Student Enrollment Form
  const [studentForm, setStudentForm] = useState<Partial<Student>>({
    name: '',
    rollNo: '',
    gender: 'male',
    guardianName: '',
    guardianPhone: '',
    guardianEmail: '',
    avatarColor: '#059669',
    photoUrl: undefined,
  });

  // Create Class Form
  const [classForm, setClassForm] = useState({
    name: '',
    code: '',
    subject: '',
    room: '',
    teacher: classroom.teacher || 'Dr. Evelyn Carter',
    academicYear: '2026 - 2027',
  });

  // Keep targetStrength in sync when classroom changes
  React.useEffect(() => {
    setTargetStrength(classroom.students.length);
    setSelectedStudentIds([]);
  }, [classroom.id, classroom.students.length]);

  // Helper to get next roll number
  const getNextRollNo = (currentCount: number) => {
    const padded = String(currentCount + 1).padStart(2, '0');
    return `${classroom.code}-${padded}`;
  };

  // --- Feature 1: Rename Student (Inline & Full Modal) ---
  const handleSaveInlineName = (studentId: string) => {
    if (!inlineNameVal.trim()) {
      setInlineEditId(null);
      return;
    }
    const updatedStudents = classroom.students.map((st) =>
      st.id === studentId ? { ...st, name: inlineNameVal.trim() } : st
    );
    onUpdateClassroom({ ...classroom, students: updatedStudents });
    playSound('complete', soundEnabled);
    setInlineEditId(null);
  };

  const handleSaveStudentEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudent || !editingStudent.name.trim()) return;

    const updatedStudents = classroom.students.map((st) =>
      st.id === editingStudent.id ? editingStudent : st
    );

    onUpdateClassroom({ ...classroom, students: updatedStudents });
    playSound('complete', soundEnabled);
    setEditingStudent(null);
  };

  // --- Feature 2: Change Strength of the Class (Quantity) ---
  const handleSetClassStrength = (newSize: number) => {
    if (newSize < 0 || isNaN(newSize)) return;

    const currentCount = classroom.students.length;
    if (newSize === currentCount) return;

    if (newSize > currentCount) {
      // Expanding class strength: generate new students
      const toAdd = newSize - currentCount;
      const newStudents: Student[] = [];

      for (let i = 0; i < toAdd; i++) {
        const idx = currentCount + i + 1;
        const padded = String(idx).padStart(2, '0');
        newStudents.push({
          id: `s_${Date.now()}_${idx}`,
          rollNo: `${classroom.code}-${padded}`,
          name: `Student ${idx}`,
          gender: idx % 2 === 0 ? 'female' : 'male',
          avatarColor: ['#059669', '#2563EB', '#7C3AED', '#DB2777', '#D97706'][idx % 5],
          guardianName: `Guardian of Student ${idx}`,
          guardianPhone: `+1 (555) 000-${String(idx).padStart(4, '0')}`,
          guardianEmail: `student${idx}@academy.edu`,
        });
      }

      const updated = {
        ...classroom,
        students: [...classroom.students, ...newStudents],
      };
      onUpdateClassroom(updated);
      playSound('complete', soundEnabled);
    } else {
      // Trimming class strength: confirm before trimming
      const diff = currentCount - newSize;
      if (
        confirm(
          `Are you sure you want to reduce class strength from ${currentCount} to ${newSize} students? The last ${diff} student(s) will be removed.`
        )
      ) {
        const updated = {
          ...classroom,
          students: classroom.students.slice(0, newSize),
        };
        onUpdateClassroom(updated);
        playSound('click', soundEnabled);
      } else {
        setTargetStrength(currentCount);
      }
    }
  };

  // Bulk Import Names
  const handleApplyBulkImport = () => {
    const lines = bulkText
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);

    if (lines.length === 0) return;

    if (bulkMode === 'replace') {
      const newStudents: Student[] = lines.map((name, i) => {
        const padded = String(i + 1).padStart(2, '0');
        return {
          id: `s_${Date.now()}_${i}`,
          rollNo: `${classroom.code}-${padded}`,
          name,
          gender: i % 2 === 0 ? 'female' : 'male',
          avatarColor: ['#059669', '#2563EB', '#7C3AED', '#DB2777', '#D97706'][i % 5],
          guardianName: `Parent of ${name.split(' ')[0]}`,
          guardianPhone: '+1 (555) 000-0000',
          guardianEmail: '',
        };
      });

      onUpdateClassroom({ ...classroom, students: newStudents });
    } else {
      // Append mode
      const currentCount = classroom.students.length;
      const newStudents: Student[] = lines.map((name, i) => {
        const idx = currentCount + i + 1;
        const padded = String(idx).padStart(2, '0');
        return {
          id: `s_${Date.now()}_${idx}`,
          rollNo: `${classroom.code}-${padded}`,
          name,
          gender: i % 2 === 0 ? 'female' : 'male',
          avatarColor: ['#059669', '#2563EB', '#7C3AED', '#DB2777', '#D97706'][idx % 5],
          guardianName: `Parent of ${name.split(' ')[0]}`,
          guardianPhone: '+1 (555) 000-0000',
          guardianEmail: '',
        };
      });

      onUpdateClassroom({
        ...classroom,
        students: [...classroom.students, ...newStudents],
      });
    }

    playSound('complete', soundEnabled);
    setShowBulkImportModal(false);
    setBulkText('');
  };

  // Single Student Enrollment
  const handleAddStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentForm.name || !studentForm.rollNo) return;

    const newStudent: Student = {
      id: `s_${Date.now()}`,
      name: studentForm.name.trim(),
      rollNo: studentForm.rollNo.trim(),
      gender: studentForm.gender || 'male',
      avatarColor: studentForm.avatarColor || '#059669',
      photoUrl: studentForm.photoUrl,
      guardianName: studentForm.guardianName || 'Parent / Guardian',
      guardianPhone: studentForm.guardianPhone || '',
      guardianEmail: studentForm.guardianEmail || '',
    };

    onUpdateClassroom({
      ...classroom,
      students: [...classroom.students, newStudent],
    });

    playSound('complete', soundEnabled);
    setShowAddStudentModal(false);
    setStudentForm({
      name: '',
      rollNo: '',
      gender: 'male',
      guardianName: '',
      guardianPhone: '',
      guardianEmail: '',
      avatarColor: '#059669',
      photoUrl: undefined,
    });
  };

  // Remove Single Student
  const handleRemoveStudent = (studentId: string, studentName: string) => {
    if (confirm(`Remove ${studentName} from this classroom?`)) {
      onUpdateClassroom({
        ...classroom,
        students: classroom.students.filter((st) => st.id !== studentId),
      });
      playSound('click', soundEnabled);
    }
  };

  // Bulk Delete Selected
  const handleDeleteSelected = () => {
    if (selectedStudentIds.length === 0) return;
    if (
      confirm(`Remove all ${selectedStudentIds.length} selected students from ${classroom.name}?`)
    ) {
      onUpdateClassroom({
        ...classroom,
        students: classroom.students.filter((st) => !selectedStudentIds.includes(st.id)),
      });
      setSelectedStudentIds([]);
      playSound('click', soundEnabled);
    }
  };

  // Toggle select all
  const handleToggleSelectAll = () => {
    if (selectedStudentIds.length === classroom.students.length) {
      setSelectedStudentIds([]);
    } else {
      setSelectedStudentIds(classroom.students.map((st) => st.id));
    }
  };

  // Create Class
  const handleCreateClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!classForm.name || !classForm.code) return;

    const newClass: Classroom = {
      id: `class_${Date.now()}`,
      name: classForm.name,
      code: classForm.code.toUpperCase(),
      subject: classForm.subject || 'General Studies',
      room: classForm.room || 'Room 101',
      teacher: classForm.teacher || 'Instructor',
      academicYear: classForm.academicYear,
      periods: ['Morning Roll Call', 'Period 1', 'Period 2'],
      students: [
        {
          id: `s_${Date.now()}_1`,
          rollNo: `${classForm.code}-01`,
          name: 'Student 01',
          gender: 'male',
          avatarColor: '#059669',
          guardianName: 'Parent / Guardian',
          guardianPhone: '+1 (555) 000-0001',
          guardianEmail: '',
        },
        {
          id: `s_${Date.now()}_2`,
          rollNo: `${classForm.code}-02`,
          name: 'Student 02',
          gender: 'female',
          avatarColor: '#2563EB',
          guardianName: 'Parent / Guardian',
          guardianPhone: '+1 (555) 000-0002',
          guardianEmail: '',
        },
      ],
    };

    onCreateClassroom(newClass);
    onSelectClass(newClass);
    playSound('complete', soundEnabled);
    setShowCreateClassModal(false);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header Info */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-600" />
              <h2 className="text-xl font-bold text-slate-900">Class Roster & Student Manager</h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Customize student names and photos, adjust class strength (capacity), and manage class enrollments.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => {
                setStudentForm((prev) => ({
                  ...prev,
                  rollNo: getNextRollNo(classroom.students.length),
                }));
                playSound('click', soundEnabled);
                setShowAddStudentModal(true);
              }}
              className="px-3.5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 rounded-xl shadow-xs transition-all flex items-center gap-1.5"
            >
              <UserPlus className="w-4 h-4" />
              <span>Enroll Student</span>
            </button>

            <button
              onClick={() => {
                playSound('click', soundEnabled);
                setShowBulkImportModal(true);
              }}
              className="px-3.5 py-2 text-xs font-bold text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 active:scale-95 rounded-xl shadow-xs transition-all flex items-center gap-1.5"
            >
              <ClipboardList className="w-4 h-4 text-emerald-600" />
              <span>Bulk Import Names</span>
            </button>

            <button
              onClick={() => {
                playSound('click', soundEnabled);
                setShowCreateClassModal(true);
              }}
              className="px-3.5 py-2 text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 active:scale-95 rounded-xl transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>New Classroom</span>
            </button>
          </div>
        </div>
      </div>

      {/* Class Switcher Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {classes.map((c) => {
          const isSelected = c.id === classroom.id;

          return (
            <div
              key={c.id}
              onClick={() => {
                playSound('click', soundEnabled);
                onSelectClass(c);
              }}
              className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-slate-900 text-white shadow-md border-slate-900 ring-2 ring-emerald-500/50'
                  : 'bg-white text-slate-900 border-slate-200 hover:border-slate-300 shadow-xs'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span
                  className={`font-mono text-xs font-bold px-2 py-0.5 rounded ${
                    isSelected ? 'bg-slate-800 text-emerald-400' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {c.code}
                </span>
                <span className={`text-xs font-bold ${isSelected ? 'text-emerald-400' : 'text-slate-600'}`}>
                  Strength: {c.students.length}
                </span>
              </div>
              <h3 className="font-bold text-sm mb-1">{c.name}</h3>
              <p className={`text-xs ${isSelected ? 'text-slate-300' : 'text-slate-500'}`}>
                {c.subject} · {c.room}
              </p>
            </div>
          );
        })}
      </div>

      {/* Class Strength (Quantity) Control Deck */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-600" />
              <h3 className="font-bold text-sm text-slate-900">Class Strength & Capacity Controls</h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Instantly scale the number of students in <strong className="text-slate-800">{classroom.name}</strong> up or down.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => handleSetClassStrength(Math.max(0, classroom.students.length - 1))}
                disabled={classroom.students.length <= 0}
                className="px-2.5 py-1 text-xs font-bold rounded-lg bg-white text-slate-700 shadow-xs hover:bg-slate-50 disabled:opacity-40"
                title="Decrease strength by 1"
              >
                -1
              </button>
              <button
                onClick={() => handleSetClassStrength(Math.max(0, classroom.students.length - 5))}
                disabled={classroom.students.length < 5}
                className="px-2.5 py-1 text-xs font-bold rounded-lg bg-white text-slate-700 shadow-xs hover:bg-slate-50 disabled:opacity-40"
                title="Decrease strength by 5"
              >
                -5
              </button>

              <div className="px-3 py-1 font-mono font-bold text-xs text-slate-900 flex items-center gap-1">
                <span className="text-slate-500 text-[11px] font-normal">Strength:</span>
                <span className="text-sm text-emerald-700 font-extrabold">{classroom.students.length}</span>
              </div>

              <button
                onClick={() => handleSetClassStrength(classroom.students.length + 1)}
                className="px-2.5 py-1 text-xs font-bold rounded-lg bg-emerald-600 text-white shadow-xs hover:bg-emerald-700"
                title="Increase strength by 1"
              >
                +1
              </button>
              <button
                onClick={() => handleSetClassStrength(classroom.students.length + 5)}
                className="px-2.5 py-1 text-xs font-bold rounded-lg bg-emerald-600 text-white shadow-xs hover:bg-emerald-700"
                title="Increase strength by 5"
              >
                +5
              </button>
            </div>

            {/* Set exact strength */}
            <div className="flex items-center gap-1.5">
              <input
                type="number"
                min="0"
                max="200"
                value={targetStrength}
                onChange={(e) => setTargetStrength(parseInt(e.target.value) || 0)}
                className="w-16 px-2.5 py-1.5 text-xs font-mono font-bold text-center border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                onClick={() => handleSetClassStrength(targetStrength)}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl transition-all"
              >
                Set Strength
              </button>
            </div>
          </div>
        </div>

        {/* Quick tips & shortcuts */}
        <div className="pt-3 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Quick Tips:</span>
            <span>Click the <strong className="text-slate-800">pencil icon</strong> next to any name to rename inline.</span>
            <span>·</span>
            <span>Hover on student avatar to upload custom photo.</span>
          </div>
          {selectedStudentIds.length > 0 && (
            <button
              onClick={handleDeleteSelected}
              className="text-xs font-bold text-rose-600 hover:text-rose-700 bg-rose-50 border border-rose-200 px-3 py-1 rounded-lg transition-colors flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete {selectedStudentIds.length} Selected</span>
            </button>
          )}
        </div>
      </div>

      {/* Student Roster Table with Photo & Inline Renaming */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h3 className="font-bold text-sm text-slate-900">
              Students Roster ({classroom.students.length} Enrolled)
            </h3>
            {classroom.students.length > 0 && (
              <label className="flex items-center gap-1.5 text-xs text-slate-500 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={selectedStudentIds.length === classroom.students.length}
                  onChange={handleToggleSelectAll}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>Select All</span>
              </label>
            )}
          </div>
          <span className="text-xs text-slate-500">Instructor: {classroom.teacher}</span>
        </div>

        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={classroom.students.length > 0 && selectedStudentIds.length === classroom.students.length}
                    onChange={handleToggleSelectAll}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                </th>
                <th className="py-3 px-3 w-16">Photo</th>
                <th className="py-3 px-3 w-24">Roll No</th>
                <th className="py-3 px-4">Student Name (Click to edit)</th>
                <th className="py-3 px-4">Gender</th>
                <th className="py-3 px-4">Guardian Contact</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {classroom.students.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    <p className="font-semibold text-slate-600 mb-1">Class roster is currently empty (Strength: 0)</p>
                    <p className="text-xs">Use "Set Strength" above or "Bulk Import Names" to add students.</p>
                  </td>
                </tr>
              ) : (
                classroom.students.map((student) => {
                  const isSelected = selectedStudentIds.includes(student.id);
                  const isInlineEditing = inlineEditId === student.id;

                  return (
                    <tr
                      key={student.id}
                      className={`hover:bg-slate-50 transition-colors ${
                        isSelected ? 'bg-emerald-50/30' : ''
                      }`}
                    >
                      <td className="py-3 px-3 text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedStudentIds((prev) => [...prev, student.id]);
                            } else {
                              setSelectedStudentIds((prev) => prev.filter((id) => id !== student.id));
                            }
                          }}
                          className="rounded text-emerald-600 focus:ring-emerald-500"
                        />
                      </td>

                      {/* Photo Avatar with upload trigger */}
                      <td className="py-3 px-3">
                        <StudentAvatar
                          student={student}
                          size="sm"
                          editable
                          onPhotoChange={(url) => {
                            const updatedStudents = classroom.students.map((st) =>
                              st.id === student.id ? { ...st, photoUrl: url } : st
                            );
                            onUpdateClassroom({ ...classroom, students: updatedStudents });
                            playSound('click', soundEnabled);
                          }}
                        />
                      </td>

                      {/* Roll No */}
                      <td className="py-3 px-3 font-mono font-bold text-slate-600">{student.rollNo}</td>

                      {/* Student Name with Inline Rename */}
                      <td className="py-3 px-4">
                        {isInlineEditing ? (
                          <div className="flex items-center gap-1.5 animate-fade-in">
                            <input
                              type="text"
                              autoFocus
                              value={inlineNameVal}
                              onChange={(e) => setInlineNameVal(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleSaveInlineName(student.id);
                                if (e.key === 'Escape') setInlineEditId(null);
                              }}
                              className="px-2 py-1 text-xs font-bold border border-emerald-500 rounded-lg focus:outline-none ring-2 ring-emerald-500/20 bg-white"
                            />
                            <button
                              onClick={() => handleSaveInlineName(student.id)}
                              className="p-1 rounded bg-emerald-600 text-white hover:bg-emerald-700"
                              title="Save name"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setInlineEditId(null)}
                              className="p-1 rounded border border-slate-300 text-slate-600 hover:bg-slate-100"
                              title="Cancel"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 group/name">
                            <span
                              onDoubleClick={() => {
                                setInlineEditId(student.id);
                                setInlineNameVal(student.name);
                              }}
                              className="font-bold text-slate-900 cursor-pointer hover:text-emerald-700 transition-colors"
                              title="Double click or click pencil to rename"
                            >
                              {student.name}
                            </span>
                            <button
                              onClick={() => {
                                setInlineEditId(student.id);
                                setInlineNameVal(student.name);
                              }}
                              className="opacity-0 group-hover/name:opacity-100 p-1 text-slate-400 hover:text-slate-700 rounded transition-opacity"
                              title="Rename student"
                            >
                              <Edit2 className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4 capitalize text-slate-600">{student.gender}</td>

                      <td className="py-3 px-4 text-slate-700 font-mono text-[11px]">
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{student.guardianPhone || 'N/A'}</span>
                        </div>
                      </td>

                      {/* Actions: Edit Full Profile + Remove */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => {
                              playSound('click', soundEnabled);
                              setEditingStudent({ ...student });
                            }}
                            className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors flex items-center gap-1"
                            title="Edit student profile & photo"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline text-xs font-semibold">Edit</span>
                          </button>
                          <button
                            onClick={() => handleRemoveStudent(student.id, student.name)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Remove student"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Brand Identity & Logo Customizer */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-emerald-600" />
            <h3 className="font-bold text-sm text-slate-900">Application Logo & Brand Style</h3>
          </div>
          <span className="text-xs text-slate-500">
            Selected Style: <strong className="text-slate-800 capitalize font-mono">{logoVariant}</strong>
          </span>
        </div>

        <p className="text-xs text-slate-500 mb-3">
          Your active application logo and branding emblem across the digital register, top navigation bar, voice assistant, and official printable attendance sheets:
        </p>

        {/* Official Banner Artwork Showcase */}
        <div className="mb-4 rounded-xl overflow-hidden border border-slate-700 bg-slate-950 shadow-sm relative group">
          <img 
            src="/assets/presentia_dark_logo.jpg" 
            alt="Official Presentia App Logo"
            className="w-full h-auto max-h-56 object-cover object-center"
            onError={(e) => {
              (e.target as HTMLImageElement).src = '/assets/presentia_logo.jpg';
            }}
          />
          <div className="absolute bottom-2.5 right-2.5 flex items-center gap-2">
            {onPlayLogoIntro && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onPlayLogoIntro();
                }}
                className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-bold shadow-md transition-all flex items-center gap-1.5 hover:scale-105 active:scale-95"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Play Logo Shatter Animation</span>
              </button>
            )}
            <div className="px-3 py-1.5 rounded-lg bg-slate-950/80 backdrop-blur-md text-white text-[11px] font-semibold border border-white/20 flex items-center gap-1.5 shadow-md">
              <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
              <span>Official Application Logo</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Option 1: Official Cyber Shield (Active User Logo) */}
          <div
            onClick={() => {
              if (onSelectLogoVariant) {
                playSound('complete', soundEnabled);
                onSelectLogoVariant('official');
              }
            }}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center gap-3 ${
              logoVariant === 'official'
                ? 'bg-sky-50/60 border-sky-500 ring-2 ring-sky-500/25 shadow-xs'
                : 'bg-slate-50 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
            }`}
          >
            <Logo size="sm" variant="official" showTagline={false} soundEnabled={false} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xs text-slate-900 truncate">Official Presentia</span>
                {logoVariant === 'official' && <Check className="w-3.5 h-3.5 text-sky-600 shrink-0" />}
              </div>
              <p className="text-[11px] text-slate-500 truncate">Cyber Shield & Glowing Check</p>
            </div>
          </div>

          {/* Option 2: Modern Monogram P */}
          <div
            onClick={() => {
              if (onSelectLogoVariant) {
                playSound('complete', soundEnabled);
                onSelectLogoVariant('monogram');
              }
            }}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center gap-3 ${
              logoVariant === 'monogram'
                ? 'bg-emerald-50/50 border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs'
                : 'bg-slate-50 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
            }`}
          >
            <Logo size="sm" variant="monogram" showTagline={false} soundEnabled={false} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xs text-slate-900 truncate">Dynamic Monogram P</span>
                {logoVariant === 'monogram' && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
              </div>
              <p className="text-[11px] text-slate-500 truncate">Soaring Checkmark Ribbon</p>
            </div>
          </div>

          {/* Option 3: Academic Shield */}
          <div
            onClick={() => {
              if (onSelectLogoVariant) {
                playSound('complete', soundEnabled);
                onSelectLogoVariant('shield');
              }
            }}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center gap-3 ${
              logoVariant === 'shield'
                ? 'bg-emerald-50/50 border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs'
                : 'bg-slate-50 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
            }`}
          >
            <Logo size="sm" variant="shield" showTagline={false} soundEnabled={false} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xs text-slate-900 truncate">Academic Crest</span>
                {logoVariant === 'shield' && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
              </div>
              <p className="text-[11px] text-slate-500 truncate">Heraldic Laurel Check</p>
            </div>
          </div>

          {/* Option 4: Digital Register Folio */}
          <div
            onClick={() => {
              if (onSelectLogoVariant) {
                playSound('complete', soundEnabled);
                onSelectLogoVariant('folio');
              }
            }}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center gap-3 ${
              logoVariant === 'folio'
                ? 'bg-emerald-50/50 border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs'
                : 'bg-slate-50 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
            }`}
          >
            <Logo size="sm" variant="folio" showTagline={false} soundEnabled={false} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xs text-slate-900 truncate">Digital Register</span>
                {logoVariant === 'folio' && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
              </div>
              <p className="text-[11px] text-slate-500 truncate">Folio Ledger Style</p>
            </div>
          </div>
        </div>
      </div>

      {/* --- Full Edit Student Profile & Photo Modal --- */}
      {editingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4 pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-900">Edit Student Profile & Photo</h3>
              <button
                onClick={() => setEditingStudent(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveStudentEdit} className="space-y-4 text-xs">
              {/* Photo Customizer */}
              <div className="flex flex-col sm:flex-row items-center gap-4 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <StudentAvatar
                  student={editingStudent}
                  size="xl"
                  editable
                  onPhotoChange={(url) => setEditingStudent({ ...editingStudent, photoUrl: url })}
                />
                <div className="space-y-1.5 text-center sm:text-left flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-800">Customize Student Photo</span>
                    {editingStudent.photoUrl && (
                      <button
                        type="button"
                        onClick={() => setEditingStudent({ ...editingStudent, photoUrl: undefined })}
                        className="text-[11px] text-rose-600 font-semibold hover:underline"
                      >
                        Remove Photo
                      </button>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Hover on avatar to upload photo file, or select a preset avatar:
                  </p>
                  <div className="flex flex-wrap items-center gap-1.5 justify-center sm:justify-start">
                    {PRESET_AVATARS.map((presetUrl, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setEditingStudent({ ...editingStudent, photoUrl: presetUrl })}
                        className={`w-7 h-7 rounded-lg overflow-hidden border-2 transition-transform hover:scale-105 ${
                          editingStudent.photoUrl === presetUrl
                            ? 'border-emerald-500 ring-2 ring-emerald-500/30'
                            : 'border-slate-200'
                        }`}
                      >
                        <img src={presetUrl} alt="Preset avatar" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Student Name *</label>
                <input
                  required
                  type="text"
                  value={editingStudent.name}
                  onChange={(e) => setEditingStudent({ ...editingStudent, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Roll / ID Number *</label>
                  <input
                    required
                    type="text"
                    value={editingStudent.rollNo}
                    onChange={(e) => setEditingStudent({ ...editingStudent, rollNo: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Gender</label>
                  <select
                    value={editingStudent.gender}
                    onChange={(e) => setEditingStudent({ ...editingStudent, gender: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white focus:outline-none"
                  >
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Guardian Name</label>
                <input
                  type="text"
                  value={editingStudent.guardianName || ''}
                  onChange={(e) => setEditingStudent({ ...editingStudent, guardianName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Guardian Phone</label>
                  <input
                    type="text"
                    value={editingStudent.guardianPhone || ''}
                    onChange={(e) => setEditingStudent({ ...editingStudent, guardianPhone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Guardian Email</label>
                  <input
                    type="email"
                    value={editingStudent.guardianEmail || ''}
                    onChange={(e) => setEditingStudent({ ...editingStudent, guardianEmail: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-xs flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Update Student</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- Bulk Import Roster Modal --- */}
      {showBulkImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xl max-w-lg w-full">
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-base text-slate-900">Bulk Import Students Roster</h3>
              </div>
              <button
                onClick={() => setShowBulkImportModal(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-500 mb-3">
              Paste student names from Excel, Google Docs, or a text list (one student name per line):
            </p>

            <textarea
              rows={8}
              value={bulkText}
              onChange={(e) => setBulkText(e.target.value)}
              placeholder={`Emma Watson\nLiam Smith\nNoah Johnson\nOlivia Brown\nLucas Davis\nAria Martinez`}
              className="w-full p-3 font-mono text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 mb-3"
            />

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl mb-4 space-y-2 text-xs">
              <span className="font-semibold text-slate-700 block">Import Mode:</span>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-1.5 cursor-pointer font-medium text-slate-800">
                  <input
                    type="radio"
                    name="bulkMode"
                    value="append"
                    checked={bulkMode === 'append'}
                    onChange={() => setBulkMode('append')}
                    className="text-emerald-600"
                  />
                  <span>Add to current roster (+{bulkText.split('\n').filter((l) => l.trim()).length})</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer font-medium text-slate-800">
                  <input
                    type="radio"
                    name="bulkMode"
                    value="replace"
                    checked={bulkMode === 'replace'}
                    onChange={() => setBulkMode('replace')}
                    className="text-emerald-600"
                  />
                  <span>Replace class roster (Sets strength to {bulkText.split('\n').filter((l) => l.trim()).length})</span>
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setShowBulkImportModal(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-semibold hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={bulkText.split('\n').filter((l) => l.trim()).length === 0}
                onClick={handleApplyBulkImport}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-xs disabled:opacity-50 flex items-center gap-1.5"
              >
                <span>Import {bulkText.split('\n').filter((l) => l.trim()).length} Students</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- Enroll Single Student Modal with Photo --- */}
      {showAddStudentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900">Enroll New Student</h3>
              <button
                onClick={() => setShowAddStudentModal(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddStudent} className="space-y-3.5 text-xs">
              {/* Photo Upload / Avatar Picker */}
              <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <StudentAvatar
                  student={{
                    name: studentForm.name || 'New Student',
                    avatarColor: studentForm.avatarColor || '#059669',
                    photoUrl: studentForm.photoUrl,
                  }}
                  size="lg"
                  editable
                  onPhotoChange={(url) => setStudentForm({ ...studentForm, photoUrl: url })}
                />
                <div className="flex-1 space-y-1">
                  <span className="font-bold text-slate-800 text-xs block">Student Photo</span>
                  <p className="text-[11px] text-slate-500">
                    Hover avatar to upload photo, or pick preset:
                  </p>
                  <div className="flex items-center gap-1">
                    {PRESET_AVATARS.slice(0, 5).map((url, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setStudentForm({ ...studentForm, photoUrl: url })}
                        className="w-6 h-6 rounded-md overflow-hidden border hover:border-emerald-500"
                      >
                        <img src={url} alt="preset" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Student Name *</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Liam Henderson"
                  value={studentForm.name}
                  onChange={(e) => setStudentForm({ ...studentForm, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Roll / ID Number *</label>
                  <input
                    required
                    type="text"
                    placeholder="e.g. 10A-21"
                    value={studentForm.rollNo}
                    onChange={(e) => setStudentForm({ ...studentForm, rollNo: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Gender</label>
                  <select
                    value={studentForm.gender}
                    onChange={(e) => setStudentForm({ ...studentForm, gender: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none"
                  >
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Guardian Name</label>
                <input
                  type="text"
                  placeholder="e.g. Eleanor Henderson"
                  value={studentForm.guardianName}
                  onChange={(e) => setStudentForm({ ...studentForm, guardianName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Guardian Phone</label>
                  <input
                    type="text"
                    placeholder="+1 (555) 000-0000"
                    value={studentForm.guardianPhone}
                    onChange={(e) => setStudentForm({ ...studentForm, guardianPhone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Guardian Email</label>
                  <input
                    type="email"
                    placeholder="parent@email.com"
                    value={studentForm.guardianEmail}
                    onChange={(e) => setStudentForm({ ...studentForm, guardianEmail: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddStudentModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-medium hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-xs"
                >
                  Enroll Student
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- Create Classroom Modal --- */}
      {showCreateClassModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xl max-w-md w-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900">Create New Classroom</h3>
              <button
                onClick={() => setShowCreateClassModal(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateClass} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Class Name *</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Grade 12 - Advanced Robotics"
                  value={classForm.name}
                  onChange={(e) => setClassForm({ ...classForm, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Class Code *</label>
                  <input
                    required
                    type="text"
                    placeholder="e.g. G12-ROB"
                    value={classForm.code}
                    onChange={(e) => setClassForm({ ...classForm, code: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-mono uppercase focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Room / Hall</label>
                  <input
                    type="text"
                    placeholder="e.g. STEM Lab 102"
                    value={classForm.room}
                    onChange={(e) => setClassForm({ ...classForm, room: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Subject Description</label>
                <input
                  type="text"
                  placeholder="e.g. Applied Electronics & Microcontrollers"
                  value={classForm.subject}
                  onChange={(e) => setClassForm({ ...classForm, subject: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateClassModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-medium hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold shadow-xs"
                >
                  Create Classroom
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
