import React, { useState, useMemo } from 'react';
import { Classroom, SessionAttendance, Student } from '../types/attendance';
import { calculateStudentStats, calculateClassSummary, StudentStats } from '../utils/storage';
import { playSound } from '../utils/audio';
import {
  TrendingUp,
  AlertTriangle,
  Award,
  Flame,
  Search,
  ArrowUpDown,
  CheckCircle2,
  XCircle,
  Eye,
  Mail,
  Phone,
  BarChart2,
  Calendar,
} from 'lucide-react';
import { StudentDossierModal } from './StudentDossierModal';
import { StudentAvatar } from './StudentAvatar';

interface StudentAnalyticsViewProps {
  classroom: Classroom;
  sessions: SessionAttendance[];
  soundEnabled: boolean;
  onUpdateClassroom?: (classroom: Classroom) => void;
}

export const StudentAnalyticsView: React.FC<StudentAnalyticsViewProps> = ({
  classroom,
  sessions,
  soundEnabled,
  onUpdateClassroom,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'at_risk' | 'honor_roll' | 'frequent_late'>('all');
  const [sortBy, setSortBy] = useState<'rate_desc' | 'rate_asc' | 'roll_asc' | 'streak_desc' | 'absences_desc'>('rate_desc');
  const [inspectStudent, setInspectStudent] = useState<Student | null>(null);

  // Compute all student stats
  const allStats: StudentStats[] = useMemo(() => {
    return classroom.students.map((st) => calculateStudentStats(st, classroom.id, sessions));
  }, [classroom, sessions]);

  // Compute class summary
  const classSummary = useMemo(() => {
    return calculateClassSummary(classroom, sessions);
  }, [classroom, sessions]);

  // Filtered and sorted student list
  const processedStudents = useMemo(() => {
    return allStats
      .filter((item) => {
        const matchesQuery =
          item.student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.student.rollNo.toLowerCase().includes(searchQuery.toLowerCase());
        if (!matchesQuery) return false;

        if (filterMode === 'at_risk') return item.isAtRisk;
        if (filterMode === 'honor_roll') return item.attendanceRate >= 98;
        if (filterMode === 'frequent_late') return item.lateCount >= 3;
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'rate_desc') return b.attendanceRate - a.attendanceRate;
        if (sortBy === 'rate_asc') return a.attendanceRate - b.attendanceRate;
        if (sortBy === 'streak_desc') return b.streak - a.streak;
        if (sortBy === 'absences_desc') return b.absentCount - a.absentCount;
        return a.student.rollNo.localeCompare(b.student.rollNo);
      });
  }, [allStats, searchQuery, filterMode, sortBy]);

  return (
    <div className="space-y-6 pb-20">
      {/* Header Info */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
              <h2 className="text-xl font-bold text-slate-900">Student Attendance Analytics</h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Longitudinal attendance rates, intervention alerts, streak leaders, and student profiles for {classroom.name}.
            </p>
          </div>
          <div className="text-xs font-semibold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200 self-start sm:self-auto">
            Threshold Alert: &lt; 75%
          </div>
        </div>
      </div>

      {/* KPI Overview Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Class Participation Avg</span>
            <BarChart2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono tabular-nums text-slate-900">
              {classSummary.averageAttendanceRate}%
            </span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-700 font-medium">
            Across {classSummary.totalSessionsRecorded} recorded sessions
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>At-Risk Students</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-3xl font-extrabold font-mono tabular-nums ${classSummary.atRiskCount > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
              {classSummary.atRiskCount}
            </span>
            <span className="text-xs text-slate-400">/ {classSummary.totalStudents}</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 font-medium">
            Attendance below 75% threshold
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Perfect Streak Leaders</span>
            <Flame className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono tabular-nums text-indigo-600">
              {classSummary.perfectStreakCount}
            </span>
            <span className="text-xs text-slate-400">students</span>
          </div>
          <div className="mt-2 text-[11px] text-indigo-600 font-medium">
            10+ consecutive days present
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Cumulative Absences</span>
            <XCircle className="w-4 h-4 text-slate-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono tabular-nums text-slate-800">
              {classSummary.totalAbsences}
            </span>
            <span className="text-xs text-slate-400">instances</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 font-medium">
            Recorded in current term
          </div>
        </div>
      </div>

      {/* Day of Week Attendance Distribution Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
        <h3 className="font-bold text-sm text-slate-900 mb-1">Weekday Attendance Patterns</h3>
        <p className="text-xs text-slate-500 mb-4">
          Compare attendance levels across Monday through Friday to detect day-specific trends.
        </p>

        <div className="grid grid-cols-5 gap-3">
          {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map((day) => {
            const data = classSummary.dayOfWeekBreakdown[day] || { sessions: 0, averageRate: 0 };
            const rate = data.averageRate;

            return (
              <div key={day} className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-center">
                <span className="text-xs font-bold text-slate-700 block mb-1">{day}</span>
                <span
                  className={`text-lg font-bold font-mono tabular-nums block ${
                    rate >= 90 ? 'text-emerald-700' : rate >= 75 ? 'text-amber-700' : 'text-rose-700'
                  }`}
                >
                  {rate > 0 ? `${rate}%` : '--'}
                </span>
                <div className="mt-2 w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${rate >= 90 ? 'bg-emerald-500' : rate >= 75 ? 'bg-amber-500' : 'bg-rose-500'}`}
                    style={{ width: `${rate}%` }}
                  />
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block font-mono">{data.sessions} sessions</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Student Roster Table with Filters & Sorting */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Segmented Filter Buttons */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-medium overflow-x-auto">
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                setFilterMode('all');
              }}
              className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                filterMode === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Students ({allStats.length})
            </button>
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                setFilterMode('at_risk');
              }}
              className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1 ${
                filterMode === 'at_risk' ? 'bg-white text-rose-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <AlertTriangle className="w-3 h-3 text-rose-600" />
              <span>At-Risk ({allStats.filter((s) => s.isAtRisk).length})</span>
            </button>
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                setFilterMode('honor_roll');
              }}
              className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1 ${
                filterMode === 'honor_roll' ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Award className="w-3 h-3 text-emerald-600" />
              <span>Honor Roll (≥98%)</span>
            </button>
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                setFilterMode('frequent_late');
              }}
              className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                filterMode === 'frequent_late' ? 'bg-white text-amber-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Frequent Late
            </button>
          </div>

          {/* Search & Sort */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search student..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none"
              />
            </div>

            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="py-1.5 px-3 text-xs font-semibold rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-none cursor-pointer"
              >
                <option value="rate_desc">Highest Rate</option>
                <option value="rate_asc">Lowest Rate</option>
                <option value="streak_desc">Longest Streak</option>
                <option value="absences_desc">Most Absences</option>
                <option value="roll_asc">Roll Number</option>
              </select>
            </div>
          </div>
        </div>

        {/* Student Table */}
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4 w-20">Roll No</th>
                <th className="py-3 px-4">Student Name</th>
                <th className="py-3 px-4">Attendance Rate</th>
                <th className="py-3 px-4 text-center">Present / Total</th>
                <th className="py-3 px-4 text-center">Absences</th>
                <th className="py-3 px-4 text-center">Active Streak</th>
                <th className="py-3 px-4">Guardian Contact</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {processedStudents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    No students match the criteria.
                  </td>
                </tr>
              ) : (
                processedStudents.map((item) => {
                  const student = item.student;

                  return (
                    <tr
                      key={student.id}
                      onClick={() => {
                        playSound('click', soundEnabled);
                        setInspectStudent(student);
                      }}
                      className="hover:bg-slate-50 transition-colors cursor-pointer"
                    >
                      <td className="py-3 px-4 font-mono font-bold text-slate-600">{student.rollNo}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <StudentAvatar student={student} size="xs" />
                          <div>
                            <span className="font-bold text-slate-900 block">{student.name}</span>
                            {item.isAtRisk && (
                              <span className="text-[10px] text-rose-600 font-semibold flex items-center gap-1">
                                <AlertTriangle className="w-2.5 h-2.5" /> Chronic Absence Risk
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-mono font-bold text-sm tabular-nums ${
                              item.attendanceRate >= 90
                                ? 'text-emerald-700'
                                : item.attendanceRate >= 75
                                ? 'text-amber-700'
                                : 'text-rose-700'
                            }`}
                          >
                            {item.attendanceRate}%
                          </span>
                          <div className="w-20 bg-slate-200 rounded-full h-1.5 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                item.attendanceRate >= 90
                                  ? 'bg-emerald-500'
                                  : item.attendanceRate >= 75
                                  ? 'bg-amber-500'
                                  : 'bg-rose-500'
                              }`}
                              style={{ width: `${item.attendanceRate}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center font-mono text-slate-700">
                        {item.presentCount} / {item.totalSessions}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`font-mono font-semibold ${
                            item.absentCount > 3
                              ? 'text-rose-700 bg-rose-50 px-2 py-0.5 rounded'
                              : 'text-slate-600'
                          }`}
                        >
                          {item.absentCount}
                        </span>
                        {item.lateCount > 0 && (
                          <span className="text-[10px] text-amber-700 block font-mono">
                            +{item.lateCount} late
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="inline-flex items-center gap-1 font-mono font-bold text-indigo-700">
                          {item.streak >= 5 && <Flame className="w-3.5 h-3.5 text-amber-500" />}
                          <span>{item.streak} d</span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="text-[11px] text-slate-600">
                          <span className="font-medium text-slate-900 block truncate">{student.guardianName}</span>
                          <span className="text-slate-500">{student.guardianPhone}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            playSound('click', soundEnabled);
                            setInspectStudent(student);
                          }}
                          className="px-2.5 py-1 text-xs font-semibold text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors border border-emerald-200"
                        >
                          Inspect
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Student Dossier Modal */}
      <StudentDossierModal
        student={inspectStudent}
        classId={classroom.id}
        sessions={sessions}
        onClose={() => setInspectStudent(null)}
        soundEnabled={soundEnabled}
        onUpdateStudent={(updatedStudent) => {
          if (onUpdateClassroom) {
            const updatedStudents = classroom.students.map((st) =>
              st.id === updatedStudent.id ? updatedStudent : st
            );
            onUpdateClassroom({
              ...classroom,
              students: updatedStudents,
            });
          }
          setInspectStudent(updatedStudent);
        }}
      />
    </div>
  );
};
