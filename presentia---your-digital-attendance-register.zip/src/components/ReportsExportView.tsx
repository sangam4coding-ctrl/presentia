import React, { useState } from 'react';
import { Classroom, SessionAttendance } from '../types/attendance';
import { generateAttendanceCSV, resetAllData } from '../utils/storage';
import { playSound } from '../utils/audio';
import { Logo } from './Logo';
import {
  FileSpreadsheet,
  Printer,
  Download,
  Upload,
  RefreshCw,
  CheckCircle2,
  FileText,
  AlertCircle,
  Building,
} from 'lucide-react';

interface ReportsExportViewProps {
  classroom: Classroom;
  sessions: SessionAttendance[];
  onDataReset: () => void;
  soundEnabled: boolean;
}

export const ReportsExportView: React.FC<ReportsExportViewProps> = ({
  classroom,
  sessions,
  onDataReset,
  soundEnabled,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Generate and download CSV
  const handleDownloadCSV = () => {
    playSound('click', soundEnabled);
    const csvContent = generateAttendanceCSV(classroom, sessions);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Attendance_Report_${classroom.code}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  // Trigger Print View
  const handlePrint = () => {
    playSound('click', soundEnabled);
    window.print();
  };

  // Export full JSON backup
  const handleExportJSON = () => {
    playSound('click', soundEnabled);
    const backupData = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      classes: JSON.parse(localStorage.getItem('presentia_classes_v1') || '[]'),
      sessions: JSON.parse(localStorage.getItem('presentia_sessions_v1') || '[]'),
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Presentia_Full_Backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Import JSON backup
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.classes && parsed.sessions) {
          localStorage.setItem('presentia_classes_v1', JSON.stringify(parsed.classes));
          localStorage.setItem('presentia_sessions_v1', JSON.stringify(parsed.sessions));
          setImportStatus('Backup successfully restored! Refreshing data...');
          playSound('complete', soundEnabled);
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        } else {
          setImportStatus('Invalid backup file structure.');
        }
      } catch {
        setImportStatus('Error parsing JSON backup file.');
      }
    };
    reader.readAsText(file);
  };

  const classSessions = sessions
    .filter((s) => s.classId === classroom.id)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="space-y-6 pb-20">
      {/* Header Info */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs no-print">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
              <h2 className="text-xl font-bold text-slate-900">Reports & Export Register</h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Download formal CSV reports, print classroom attendance registers, or backup data for {classroom.name}.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleDownloadCSV}
              className="px-3.5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 rounded-xl shadow-xs transition-all flex items-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Download CSV Sheet</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-3.5 py-2 text-xs font-bold text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 active:scale-95 rounded-xl shadow-xs transition-all flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4 text-slate-600" />
              <span>Print Official Register</span>
            </button>
          </div>
        </div>

        {downloadSuccess && (
          <div className="mt-3 p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 font-semibold flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>CSV Attendance Sheet has been generated and downloaded to your device!</span>
          </div>
        )}
      </div>

      {/* Printable Sheet View Container */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm overflow-hidden print:border-none print:shadow-none print:p-0">
        {/* Official School Formal Header */}
        <div className="border-b-2 border-slate-900 pb-4 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Logo size="sm" showTagline={false} soundEnabled={soundEnabled} />
              <div className="pl-3 border-l border-slate-300">
                <h1 className="text-base font-bold text-slate-900 uppercase tracking-tight">
                  St. Peter's International Academy
                </h1>
                <p className="text-[11px] text-slate-500 font-medium">
                  Official Academic Attendance Register · Academic Year {classroom.academicYear}
                </p>
              </div>
            </div>

            <div className="text-right text-xs">
              <span className="font-bold text-slate-900 block">{classroom.name}</span>
              <span className="text-slate-500">{classroom.subject} · {classroom.room}</span>
              <span className="text-slate-500 block font-mono text-[11px]">Teacher: {classroom.teacher}</span>
            </div>
          </div>
        </div>

        {/* Ledger Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100 border-y border-slate-300 text-[10px] font-bold text-slate-700 uppercase">
                <th className="py-2 px-2.5 w-16 border-r border-slate-200">Roll No</th>
                <th className="py-2 px-3 min-w-[140px] border-r border-slate-200">Student Name</th>
                {classSessions.slice(-15).map((s) => (
                  <th key={s.id} className="py-2 px-1 text-center font-mono border-r border-slate-200 text-[9px] w-9">
                    {s.date.split('-')[2]}
                    <span className="block text-[8px] text-slate-400 font-normal">
                      {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'][new Date(s.date).getDay()]}
                    </span>
                  </th>
                ))}
                <th className="py-2 px-2 text-center w-12 font-bold text-emerald-800 border-r border-slate-200">P</th>
                <th className="py-2 px-2 text-center w-12 font-bold text-rose-800 border-r border-slate-200">A</th>
                <th className="py-2 px-2 text-center w-12 font-bold text-amber-800 border-r border-slate-200">L</th>
                <th className="py-2 px-3 text-right w-16 font-bold">Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
              {classroom.students.map((student) => {
                let present = 0;
                let absent = 0;
                let late = 0;

                const lastSessions = classSessions.slice(-15);
                const marks = lastSessions.map((session) => {
                  const rec = session.records[student.id];
                  if (!rec) return '-';
                  if (rec.status === 'present') {
                    present++;
                    return 'P';
                  }
                  if (rec.status === 'absent') {
                    absent++;
                    return 'A';
                  }
                  if (rec.status === 'late') {
                    late++;
                    return 'L';
                  }
                  if (rec.status === 'excused') {
                    return 'E';
                  }
                  return '-';
                });

                const total = present + absent + late;
                const rate = total > 0 ? Math.round(((present + late * 0.8) / total) * 100) : 0;

                return (
                  <tr key={student.id} className="hover:bg-slate-50">
                    <td className="py-2 px-2.5 font-bold text-slate-700 border-r border-slate-200">
                      {student.rollNo}
                    </td>
                    <td className="py-2 px-3 font-sans font-medium text-slate-900 border-r border-slate-200 truncate">
                      {student.name}
                    </td>
                    {marks.map((m, idx) => (
                      <td
                        key={idx}
                        className={`py-2 px-1 text-center font-bold border-r border-slate-200 ${
                          m === 'P'
                            ? 'text-emerald-700 bg-emerald-50/20'
                            : m === 'A'
                            ? 'text-rose-700 bg-rose-50/40 font-extrabold'
                            : m === 'L'
                            ? 'text-amber-700 bg-amber-50/30'
                            : 'text-slate-400'
                        }`}
                      >
                        {m}
                      </td>
                    ))}
                    <td className="py-2 px-2 text-center text-emerald-800 font-bold border-r border-slate-200">
                      {present}
                    </td>
                    <td className="py-2 px-2 text-center text-rose-800 font-bold border-r border-slate-200">
                      {absent}
                    </td>
                    <td className="py-2 px-2 text-center text-amber-800 font-bold border-r border-slate-200">
                      {late}
                    </td>
                    <td
                      className={`py-2 px-3 text-right font-bold tabular-nums ${
                        rate >= 90 ? 'text-emerald-700' : rate >= 75 ? 'text-amber-700' : 'text-rose-700'
                      }`}
                    >
                      {rate}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Formal Signature Footer (Visible in Print & Preview) */}
        <div className="mt-10 pt-6 border-t border-slate-200 grid grid-cols-3 gap-6 text-xs text-slate-600">
          <div>
            <p className="font-semibold text-slate-800 mb-8">Class Instructor Signature:</p>
            <div className="border-b border-slate-400 w-44" />
            <p className="text-[11px] text-slate-500 mt-1">{classroom.teacher}</p>
          </div>

          <div>
            <p className="font-semibold text-slate-800 mb-8">Academic Dean / Vice Principal:</p>
            <div className="border-b border-slate-400 w-44" />
            <p className="text-[11px] text-slate-500 mt-1">Institutional Verification</p>
          </div>

          <div className="text-right">
            <p className="font-semibold text-slate-800 mb-8">Register Audit Date:</p>
            <p className="font-mono text-xs text-slate-900 font-bold">{new Date().toLocaleDateString()}</p>
            <p className="text-[10px] text-slate-400 mt-1">Generated via Presentia Attendance OS</p>
          </div>
        </div>
      </div>

      {/* System Backup, Data Restore & Sample Reset Deck (Screen Only) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4 no-print">
        <h3 className="font-bold text-sm text-slate-900">Database Backup & Recovery</h3>
        <p className="text-xs text-slate-500">
          Save an offline backup copy of all classrooms, student rosters, and historical attendance logs, or restore from a previous JSON file.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleExportJSON}
            className="px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-800 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            <span>Export JSON Database</span>
          </button>

          <label className="px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-800 flex items-center gap-1.5 transition-colors cursor-pointer">
            <Upload className="w-3.5 h-3.5 text-slate-600" />
            <span>Restore JSON Backup</span>
            <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
          </label>

          <button
            onClick={() => {
              if (confirm('Reset database back to initial sample classrooms and 30-day pre-seeded history?')) {
                resetAllData();
                onDataReset();
                playSound('complete', soundEnabled);
              }
            }}
            className="px-3 py-1.5 rounded-xl border border-rose-200 text-rose-700 bg-rose-50 hover:bg-rose-100 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5 text-rose-600" />
            <span>Reset to Pre-Seeded Sample Data</span>
          </button>
        </div>

        {importStatus && (
          <p className="text-xs font-semibold text-slate-800 bg-slate-100 p-2.5 rounded-lg border border-slate-200">
            {importStatus}
          </p>
        )}
      </div>
    </div>
  );
};
