import React, { useState, useMemo } from 'react';
import { Classroom, SessionAttendance, AttendanceStatus } from '../types/attendance';
import { playSound } from '../utils/audio';
import {
  Calendar as CalendarIcon,
  CheckCircle2,
  XCircle,
  Clock,
  ChevronLeft,
  ChevronRight,
  FileSpreadsheet,
  Trash2,
  Edit3,
  Copy,
  Check,
  Search,
  Flame,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

interface HistoryHeatmapViewProps {
  classroom: Classroom;
  sessions: SessionAttendance[];
  onSelectSessionToEdit: (session: SessionAttendance) => void;
  onDeleteSession: (sessionId: string) => void;
  soundEnabled: boolean;
}

export const HistoryHeatmapView: React.FC<HistoryHeatmapViewProps> = ({
  classroom,
  sessions,
  onSelectSessionToEdit,
  onDeleteSession,
  soundEnabled,
}) => {
  // Calendar month state
  const [currentYear, setCurrentYear] = useState<number>(2026);
  const [currentMonth, setCurrentMonth] = useState<number>(9); // 0-indexed, 9 = October

  // Filter & Search
  const [searchDate, setSearchDate] = useState('');
  const [filterPeriod, setFilterPeriod] = useState<string>('all');
  const [onlyWithAbsences, setOnlyWithAbsences] = useState(false);

  // Selected session for detailed inspection
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);
  const [copiedAbsentList, setCopiedAbsentList] = useState(false);

  // Filter sessions for this class
  const classSessions = useMemo(() => {
    return sessions
      .filter((s) => s.classId === classroom.id)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [sessions, classroom.id]);

  // Set default selected session to latest recorded
  const activeSession = useMemo(() => {
    if (selectedSessionId) {
      const found = classSessions.find((s) => s.id === selectedSessionId);
      if (found) return found;
    }
    return classSessions[0] || null;
  }, [classSessions, selectedSessionId]);

  // Month navigation
  const prevMonth = () => {
    playSound('click', soundEnabled);
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const nextMonth = () => {
    playSound('click', soundEnabled);
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  // Build calendar matrix for currentMonth
  const calendarData = useMemo(() => {
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
    const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);

    const startingDayOfWeek = firstDayOfMonth.getDay(); // 0 is Sunday
    const totalDays = lastDayOfMonth.getDate();

    const days: Array<{
      dateStr: string;
      dayNumber: number;
      isCurrentMonth: boolean;
      session?: SessionAttendance;
      rate?: number;
      absentCount?: number;
    }> = [];

    // Preceding empty slots
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push({
        dateStr: '',
        dayNumber: 0,
        isCurrentMonth: false,
      });
    }

    // Days in month
    for (let d = 1; d <= totalDays; d++) {
      const monthPadded = String(currentMonth + 1).padStart(2, '0');
      const dayPadded = String(d).padStart(2, '0');
      const dateStr = `${currentYear}-${monthPadded}-${dayPadded}`;

      // find session for this day
      const session = classSessions.find((s) => s.date === dateStr);

      let rate: number | undefined = undefined;
      let absentCount: number | undefined = undefined;

      if (session) {
        const recordsArr = Object.values(session.records);
        if (recordsArr.length > 0) {
          const presentCount = recordsArr.filter((r) => r.status === 'present').length;
          const lateCount = recordsArr.filter((r) => r.status === 'late').length;
          absentCount = recordsArr.filter((r) => r.status === 'absent').length;
          rate = Math.round(((presentCount + lateCount * 0.8) / recordsArr.length) * 100);
        }
      }

      days.push({
        dateStr,
        dayNumber: d,
        isCurrentMonth: true,
        session,
        rate,
        absentCount,
      });
    }

    return days;
  }, [currentYear, currentMonth, classSessions]);

  // Filtered session list for timeline
  const filteredTimelineSessions = useMemo(() => {
    return classSessions.filter((s) => {
      if (searchDate && !s.date.includes(searchDate)) return false;
      if (filterPeriod !== 'all' && s.period !== filterPeriod) return false;
      if (onlyWithAbsences) {
        const abs = Object.values(s.records).filter((r) => r.status === 'absent').length;
        if (abs === 0) return false;
      }
      return true;
    });
  }, [classSessions, searchDate, filterPeriod, onlyWithAbsences]);

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Copy absentee list to clipboard
  const handleCopyAbsenteeList = () => {
    if (!activeSession) return;
    const absentees = classroom.students
      .filter((st) => activeSession.records[st.id]?.status === 'absent')
      .map((st) => {
        const rec = activeSession.records[st.id];
        return `• ${st.rollNo} - ${st.name} (Guardian: ${st.guardianPhone}) ${rec?.note ? `[Reason: ${rec.note}]` : ''}`;
      });

    const text = `ABSENTEE REPORT - ${classroom.name}
Date: ${activeSession.date} · Period: ${activeSession.period}
Total Absentees: ${absentees.length}

${absentees.length > 0 ? absentees.join('\n') : 'Perfect Attendance! All students present.'}

Recorded by: ${activeSession.takenBy}`;

    navigator.clipboard.writeText(text);
    setCopiedAbsentList(true);
    playSound('click', soundEnabled);
    setTimeout(() => setCopiedAbsentList(false), 2200);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header Info */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-emerald-600" />
              <h2 className="text-xl font-bold text-slate-900">Attendance History & Heatmap</h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Visual historical calendar, retroactive session logs, and absence breakdowns for {classroom.name}.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="font-semibold text-slate-700 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200">
              Total Logged Sessions: <span className="font-mono font-bold text-slate-900">{classSessions.length}</span>
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Heatmap Calendar on Left, Deep Dive Details on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Heatmap Calendar (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            {/* Calendar Month Selector */}
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">
                  {monthNames[currentMonth]} {currentYear}
                </h3>
                <span className="text-xs text-slate-400">· Click date to inspect</span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={prevMonth}
                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={nextMonth}
                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 transition-colors"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Day of Week Headers */}
            <div className="grid grid-cols-7 gap-2 mb-2 text-center text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              <span>Sun</span>
              <span>Mon</span>
              <span>Tue</span>
              <span>Wed</span>
              <span>Thu</span>
              <span>Fri</span>
              <span>Sat</span>
            </div>

            {/* Calendar Day Matrix */}
            <div className="grid grid-cols-7 gap-2">
              {calendarData.map((day, idx) => {
                if (!day.isCurrentMonth) {
                  return <div key={idx} className="h-16 rounded-xl bg-slate-50/50 border border-transparent" />;
                }

                const isSelected = activeSession && activeSession.date === day.dateStr;
                const hasSession = !!day.session;
                const rate = day.rate ?? 0;

                // Color tiering
                let bgStyle = 'bg-slate-50 border-slate-200 hover:bg-slate-100';
                let rateColor = 'text-slate-400';

                if (hasSession) {
                  if (rate >= 95) {
                    bgStyle = 'bg-emerald-50 border-emerald-300 hover:bg-emerald-100/80';
                    rateColor = 'text-emerald-700 font-bold';
                  } else if (rate >= 85) {
                    bgStyle = 'bg-teal-50 border-teal-300 hover:bg-teal-100/80';
                    rateColor = 'text-teal-700 font-bold';
                  } else if (rate >= 75) {
                    bgStyle = 'bg-amber-50 border-amber-300 hover:bg-amber-100/80';
                    rateColor = 'text-amber-700 font-bold';
                  } else {
                    bgStyle = 'bg-rose-50 border-rose-300 hover:bg-rose-100/80';
                    rateColor = 'text-rose-700 font-bold';
                  }
                }

                return (
                  <div
                    key={idx}
                    onClick={() => {
                      if (day.session) {
                        playSound('click', soundEnabled);
                        setSelectedSessionId(day.session.id);
                      }
                    }}
                    className={`h-16 p-1.5 rounded-xl border flex flex-col justify-between transition-all duration-150 ${
                      hasSession ? 'cursor-pointer hover:shadow-sm' : 'opacity-40 cursor-default'
                    } ${isSelected ? 'ring-2 ring-slate-900 shadow-sm' : ''} ${bgStyle}`}
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-800">{day.dayNumber}</span>
                      {hasSession && day.absentCount !== undefined && day.absentCount > 0 && (
                        <span className="text-[10px] font-bold text-rose-600 bg-rose-100/80 px-1 rounded">
                          -{day.absentCount}
                        </span>
                      )}
                    </div>

                    <div className="text-right">
                      {hasSession ? (
                        <span className={`text-[11px] font-mono tabular-nums ${rateColor}`}>
                          {rate}%
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-300">--</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Heatmap Legend */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-2">
              <span className="font-medium">Attendance Rate Scale:</span>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <div className="w-3.5 h-3.5 rounded bg-emerald-500" />
                  <span className="text-[11px]">≥ 95%</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3.5 h-3.5 rounded bg-teal-500" />
                  <span className="text-[11px]">85 - 94%</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3.5 h-3.5 rounded bg-amber-500" />
                  <span className="text-[11px]">75 - 84%</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3.5 h-3.5 rounded bg-rose-500" />
                  <span className="text-[11px]">&lt; 75%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Historical Sessions Feed with filters */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <h3 className="font-bold text-sm text-slate-900">All Past Roll Call Sessions</h3>

              <div className="flex flex-wrap items-center gap-2">
                <input
                  type="text"
                  placeholder="Filter by date (YYYY-MM)..."
                  value={searchDate}
                  onChange={(e) => setSearchDate(e.target.value)}
                  className="px-2.5 py-1 text-xs rounded-lg border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none"
                />
                <button
                  onClick={() => setOnlyWithAbsences((prev) => !prev)}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition-colors ${
                    onlyWithAbsences
                      ? 'bg-rose-50 text-rose-800 border-rose-300'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Only with Absences
                </button>
              </div>
            </div>

            <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 border border-slate-100 rounded-xl">
              {filteredTimelineSessions.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400">No sessions match search query.</div>
              ) : (
                filteredTimelineSessions.map((session) => {
                  const recordsArr = Object.values(session.records);
                  const present = recordsArr.filter((r) => r.status === 'present').length;
                  const absent = recordsArr.filter((r) => r.status === 'absent').length;
                  const late = recordsArr.filter((r) => r.status === 'late').length;
                  const rate =
                    recordsArr.length > 0 ? Math.round(((present + late * 0.8) / recordsArr.length) * 100) : 0;
                  const isSelected = activeSession?.id === session.id;

                  return (
                    <div
                      key={session.id}
                      onClick={() => {
                        playSound('click', soundEnabled);
                        setSelectedSessionId(session.id);
                      }}
                      className={`p-3.5 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition-colors ${
                        isSelected ? 'bg-slate-100/80 font-medium' : ''
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${
                            rate >= 90
                              ? 'bg-emerald-100 text-emerald-800'
                              : rate >= 75
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {rate}%
                        </div>
                        <div>
                          <span className="font-bold text-xs text-slate-900 block">{session.date}</span>
                          <span className="text-[11px] text-slate-500">{session.period}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="text-emerald-700 font-semibold">{present} Present</span>
                          <span className="text-slate-300">·</span>
                          <span className={`${absent > 0 ? 'text-rose-600 font-bold' : 'text-slate-400'}`}>
                            {absent} Absent
                          </span>
                        </div>
                        <span className="text-slate-400 text-xs">›</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Detailed Session Dossier & Absentees (5 cols) */}
        <div className="lg:col-span-5">
          {activeSession ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-5 sticky top-20">
              {/* Header with Edit & Delete actions */}
              <div className="flex items-start justify-between pb-4 border-b border-slate-100">
                <div>
                  <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
                    Session Snapshot
                  </span>
                  <h3 className="text-lg font-bold text-slate-900">{activeSession.date}</h3>
                  <p className="text-xs text-slate-500">{activeSession.period} · Teacher: {activeSession.takenBy}</p>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => {
                      playSound('click', soundEnabled);
                      onSelectSessionToEdit(activeSession);
                    }}
                    className="p-2 rounded-xl text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 border border-slate-200 transition-colors"
                    title="Edit this session retroactively"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Are you sure you want to delete session ${activeSession.date}?`)) {
                        playSound('click', soundEnabled);
                        onDeleteSession(activeSession.id);
                      }
                    }}
                    className="p-2 rounded-xl text-slate-400 hover:text-rose-700 hover:bg-rose-50 border border-slate-200 transition-colors"
                    title="Delete session record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Session Performance Meter */}
              {(() => {
                const recordsArr = Object.values(activeSession.records);
                const present = recordsArr.filter((r) => r.status === 'present').length;
                const absent = recordsArr.filter((r) => r.status === 'absent').length;
                const late = recordsArr.filter((r) => r.status === 'late').length;
                const excused = recordsArr.filter((r) => r.status === 'excused').length;
                const rate = recordsArr.length > 0 ? Math.round(((present + late * 0.8) / recordsArr.length) * 100) : 0;

                return (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-slate-600">Turnout Rate</span>
                      <span className="text-xl font-bold font-mono text-emerald-700">{rate}%</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden mb-3">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${rate}%` }} />
                    </div>

                    <div className="grid grid-cols-4 gap-2 text-center text-xs">
                      <div className="p-1.5 bg-white rounded-lg border border-slate-200">
                        <span className="text-[10px] text-slate-400 block">Present</span>
                        <span className="font-bold text-emerald-700">{present}</span>
                      </div>
                      <div className="p-1.5 bg-white rounded-lg border border-slate-200">
                        <span className="text-[10px] text-slate-400 block">Absent</span>
                        <span className="font-bold text-rose-700">{absent}</span>
                      </div>
                      <div className="p-1.5 bg-white rounded-lg border border-slate-200">
                        <span className="text-[10px] text-slate-400 block">Late</span>
                        <span className="font-bold text-amber-700">{late}</span>
                      </div>
                      <div className="p-1.5 bg-white rounded-lg border border-slate-200">
                        <span className="text-[10px] text-slate-400 block">Excused</span>
                        <span className="font-bold text-sky-700">{excused}</span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Absentee & Exceptions Dossier */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Absences & Exceptions
                  </h4>
                  <button
                    onClick={handleCopyAbsenteeList}
                    className="text-xs font-semibold text-slate-700 hover:text-slate-900 flex items-center gap-1 underline"
                  >
                    {copiedAbsentList ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedAbsentList ? 'Copied!' : 'Copy Summary'}</span>
                  </button>
                </div>

                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {classroom.students.filter(
                    (st) =>
                      activeSession.records[st.id]?.status === 'absent' ||
                      activeSession.records[st.id]?.status === 'late' ||
                      activeSession.records[st.id]?.status === 'excused'
                  ).length === 0 ? (
                    <div className="p-4 text-center rounded-xl bg-emerald-50/60 border border-emerald-200 text-xs text-emerald-800 font-semibold flex items-center justify-center gap-2">
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      <span>Perfect Turnout! Zero absences for this roll call.</span>
                    </div>
                  ) : (
                    classroom.students
                      .filter(
                        (st) =>
                          activeSession.records[st.id]?.status === 'absent' ||
                          activeSession.records[st.id]?.status === 'late' ||
                          activeSession.records[st.id]?.status === 'excused'
                      )
                      .map((student) => {
                        const rec = activeSession.records[student.id];
                        const status = rec?.status;

                        return (
                          <div
                            key={student.id}
                            className={`p-3 rounded-xl border flex items-start justify-between text-xs ${
                              status === 'absent'
                                ? 'bg-rose-50/60 border-rose-200'
                                : status === 'late'
                                ? 'bg-amber-50/60 border-amber-200'
                                : 'bg-sky-50/60 border-sky-200'
                            }`}
                          >
                            <div className="flex items-start gap-2.5">
                              <div
                                className="w-7 h-7 rounded-lg flex items-center justify-center text-white font-bold text-[11px] shrink-0"
                                style={{ backgroundColor: student.avatarColor }}
                              >
                                {student.name
                                  .split(' ')
                                  .map((n) => n[0])
                                  .slice(0, 2)
                                  .join('')}
                              </div>
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <span className="font-bold text-slate-900">{student.name}</span>
                                  <span className="font-mono text-[10px] text-slate-500">({student.rollNo})</span>
                                </div>
                                <span className="text-[11px] text-slate-500 block">
                                  Guardian: {student.guardianPhone}
                                </span>
                                {rec?.note && (
                                  <span className="text-[11px] italic text-slate-700 mt-1 block">
                                    "{rec.note}"
                                  </span>
                                )}
                              </div>
                            </div>

                            <span
                              className={`font-semibold capitalize px-2 py-0.5 rounded text-[10px] ${
                                status === 'absent'
                                  ? 'bg-rose-600 text-white'
                                  : status === 'late'
                                  ? 'bg-amber-600 text-white'
                                  : 'bg-sky-600 text-white'
                              }`}
                            >
                              {status}
                            </span>
                          </div>
                        );
                      })
                  )}
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                <button
                  onClick={() => {
                    playSound('click', soundEnabled);
                    onSelectSessionToEdit(activeSession);
                  }}
                  className="flex-1 py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Edit3 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Update Attendance</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-xs text-slate-400">
              No session selected. Click any session from the calendar or timeline.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
