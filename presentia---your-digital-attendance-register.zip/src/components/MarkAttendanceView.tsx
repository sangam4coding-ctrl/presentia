import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Classroom, AttendanceStatus, SessionAttendance, Student } from '../types/attendance';
import { playSound } from '../utils/audio';
import confetti from 'canvas-confetti';
import {
  Check,
  X,
  Clock,
  ShieldCheck,
  Search,
  LayoutGrid,
  List,
  Sparkles,
  Save,
  RotateCcw,
  CheckCheck,
  Calendar,
  Layers,
  MessageSquare,
  HelpCircle,
  Eye,
  Shuffle,
  Send,
} from 'lucide-react';
import { StudentDossierModal } from './StudentDossierModal';
import { RandomPickerModal } from './RandomPickerModal';
import { StudentAvatar } from './StudentAvatar';
import { VoiceAttendanceAssistant } from './VoiceAttendanceAssistant';

interface MarkAttendanceViewProps {
  classroom: Classroom;
  sessions: SessionAttendance[];
  onSaveSession: (session: SessionAttendance) => void;
  soundEnabled: boolean;
  onUpdateClassroom?: (classroom: Classroom) => void;
}

export const MarkAttendanceView: React.FC<MarkAttendanceViewProps> = ({
  classroom,
  sessions,
  onSaveSession,
  soundEnabled,
  onUpdateClassroom,
}) => {
  // Current active date & period
  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [selectedPeriod, setSelectedPeriod] = useState<string>(
    classroom.periods[0] || 'Morning Roll Call'
  );

  // View presentation mode: 'grid' | 'list' | 'seating'
  const [viewMode, setViewMode] = useState<'grid' | 'list' | 'seating'>('grid');

  // Search query & status filter
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | AttendanceStatus | 'unmarked'>('all');

  // Active student index for keyboard navigation speed mode
  const [focusedStudentIdx, setFocusedStudentIdx] = useState<number | null>(null);

  // Modals
  const [inspectStudent, setInspectStudent] = useState<Student | null>(null);
  const [showRandomPicker, setShowRandomPicker] = useState(false);
  const [noteStudentId, setNoteStudentId] = useState<string | null>(null);
  const [tempNoteText, setTempNoteText] = useState('');
  const [justSavedNotice, setJustSavedNotice] = useState(false);

  // Current session attendance map: studentId -> { status, note }
  const [currentRecords, setCurrentRecords] = useState<Record<string, { status: AttendanceStatus; note?: string }>>({});

  // Sync selected period if classroom changes
  useEffect(() => {
    if (classroom.periods.length > 0 && !classroom.periods.includes(selectedPeriod)) {
      setSelectedPeriod(classroom.periods[0]);
    }
  }, [classroom, selectedPeriod]);

  // Load existing session record for selectedDate + selectedPeriod if available, or prefill
  useEffect(() => {
    const existing = sessions.find(
      (s) => s.classId === classroom.id && s.date === selectedDate && s.period === selectedPeriod
    );

    if (existing) {
      const recordsMap: Record<string, { status: AttendanceStatus; note?: string }> = {};
      classroom.students.forEach((st) => {
        if (existing.records[st.id]) {
          recordsMap[st.id] = {
            status: existing.records[st.id].status,
            note: existing.records[st.id].note,
          };
        }
      });
      setCurrentRecords(recordsMap);
    } else {
      // Clean slate for new session
      setCurrentRecords({});
    }
    setFocusedStudentIdx(null);
  }, [classroom, selectedDate, selectedPeriod, sessions]);

  // Handle single student status mark
  const handleMark = (studentId: string, status: AttendanceStatus, customSound = true) => {
    if (customSound) {
      playSound(status, soundEnabled);
    }

    setCurrentRecords((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        status,
      },
    }));
  };

  // Keyboard navigation listener (P = Present, A = Absent, L = Late, E = Excused, Arrows)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in search input or note textarea
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      const activeList = filteredStudents;
      if (activeList.length === 0) return;

      if (e.key === 'ArrowDown' || e.key === 'j') {
        e.preventDefault();
        setFocusedStudentIdx((prev) => (prev === null || prev >= activeList.length - 1 ? 0 : prev + 1));
      } else if (e.key === 'ArrowUp' || e.key === 'k') {
        e.preventDefault();
        setFocusedStudentIdx((prev) => (prev === null || prev <= 0 ? activeList.length - 1 : prev - 1));
      } else if (focusedStudentIdx !== null && activeList[focusedStudentIdx]) {
        const currentStudent = activeList[focusedStudentIdx];
        const key = e.key.toLowerCase();
        if (key === 'p') {
          e.preventDefault();
          handleMark(currentStudent.id, 'present');
          // auto advance
          setFocusedStudentIdx((prev) => (prev !== null && prev < activeList.length - 1 ? prev + 1 : prev));
        } else if (key === 'a') {
          e.preventDefault();
          handleMark(currentStudent.id, 'absent');
          setFocusedStudentIdx((prev) => (prev !== null && prev < activeList.length - 1 ? prev + 1 : prev));
        } else if (key === 'l') {
          e.preventDefault();
          handleMark(currentStudent.id, 'late');
          setFocusedStudentIdx((prev) => (prev !== null && prev < activeList.length - 1 ? prev + 1 : prev));
        } else if (key === 'e') {
          e.preventDefault();
          handleMark(currentStudent.id, 'excused');
          setFocusedStudentIdx((prev) => (prev !== null && prev < activeList.length - 1 ? prev + 1 : prev));
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [focusedStudentIdx, classroom.students, soundEnabled]);

  // Batch actions
  const handleMarkAll = (status: AttendanceStatus) => {
    playSound(status, soundEnabled);
    const updated: Record<string, { status: AttendanceStatus; note?: string }> = {};
    classroom.students.forEach((st) => {
      updated[st.id] = {
        ...currentRecords[st.id],
        status,
      };
    });
    setCurrentRecords(updated);
  };

  const handleMarkRemainingPresent = () => {
    playSound('present', soundEnabled);
    const updated = { ...currentRecords };
    classroom.students.forEach((st) => {
      if (!updated[st.id]?.status) {
        updated[st.id] = { status: 'present' };
      }
    });
    setCurrentRecords(updated);
  };

  const handleResetMarks = () => {
    playSound('click', soundEnabled);
    setCurrentRecords({});
  };

  // Save attendance session
  const handleSave = () => {
    const recordsPayload: SessionAttendance['records'] = {};
    classroom.students.forEach((st) => {
      const rec = currentRecords[st.id];
      recordsPayload[st.id] = {
        studentId: st.id,
        status: rec?.status || 'unmarked' as AttendanceStatus,
        timestamp: new Date().toISOString(),
        note: rec?.note,
      };
    });

    const sessionId = `${classroom.id}_${selectedDate}_${selectedPeriod.replace(/\s+/g, '_')}`;
    const sessionPayload: SessionAttendance = {
      id: sessionId,
      classId: classroom.id,
      date: selectedDate,
      period: selectedPeriod,
      records: recordsPayload,
      takenBy: classroom.teacher,
      lastUpdated: new Date().toISOString(),
    };

    onSaveSession(sessionPayload);
    playSound('complete', soundEnabled);

    // Trigger celebratory confetti if 100% present or complete
    const presentCount = Object.values(recordsPayload).filter((r) => r.status === 'present').length;
    if (presentCount === classroom.students.length && classroom.students.length > 0) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10B981', '#3B82F6', '#F59E0B'],
      });
    }

    setJustSavedNotice(true);
    setTimeout(() => setJustSavedNotice(false), 3000);
  };

  // Filter and search students
  const filteredStudents = useMemo(() => {
    return classroom.students.filter((st) => {
      const matchesSearch =
        st.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        st.rollNo.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      const rec = currentRecords[st.id];
      if (statusFilter === 'all') return true;
      if (statusFilter === 'unmarked') return !rec || !rec.status;
      return rec?.status === statusFilter;
    });
  }, [classroom.students, searchQuery, statusFilter, currentRecords]);

  // Counts and Metrics
  const totalCount = classroom.students.length;
  const presentCount = Object.values(currentRecords).filter((r) => r.status === 'present').length;
  const absentCount = Object.values(currentRecords).filter((r) => r.status === 'absent').length;
  const lateCount = Object.values(currentRecords).filter((r) => r.status === 'late').length;
  const excusedCount = Object.values(currentRecords).filter((r) => r.status === 'excused').length;
  const markedCount = presentCount + absentCount + lateCount + excusedCount;
  const unmarkedCount = Math.max(0, totalCount - markedCount);
  const attendanceRate = markedCount > 0 ? Math.round(((presentCount + lateCount * 0.8) / markedCount) * 100) : 0;
  const isComplete = markedCount === totalCount && totalCount > 0;

  return (
    <div className="space-y-6 pb-24">
      {/* Top Banner & Control Deck */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Class info */}
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                {classroom.code}
              </span>
              <h2 className="text-xl font-bold text-slate-900">{classroom.name}</h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {classroom.subject} · {classroom.room} · Instructor: {classroom.teacher}
            </p>
          </div>

          {/* Date & Period Controls */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Quick date buttons */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-medium">
              <button
                onClick={() => {
                  const d = new Date();
                  d.setDate(d.getDate() - 1);
                  setSelectedDate(d.toISOString().split('T')[0]);
                }}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  selectedDate !== todayStr ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Yesterday
              </button>
              <button
                onClick={() => setSelectedDate(todayStr)}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  selectedDate === todayStr ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Today
              </button>
            </div>

            {/* Custom Date Input */}
            <div className="relative flex items-center">
              <Calendar className="w-3.5 h-3.5 text-slate-400 absolute left-3 pointer-events-none" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs font-mono font-medium rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Period / Session selector */}
            <div className="relative">
              <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="py-1.5 px-3 text-xs font-semibold rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
              >
                {classroom.periods.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>

            {/* Random student picker */}
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                setShowRandomPicker(true);
              }}
              className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors flex items-center gap-1.5"
              title="Pick a random student"
            >
              <Shuffle className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Random Picker</span>
            </button>
          </div>
        </div>

        {/* Live Metric / Tally Strip */}
        <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-5 gap-3">
          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-500 font-medium block">Total Roster</span>
              <span className="text-xl font-bold font-mono tabular-nums text-slate-900">{totalCount}</span>
            </div>
            <span className="text-xs font-mono text-slate-500">100%</span>
          </div>

          <div className="p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-200/60 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-emerald-800 font-semibold block">Present</span>
              <span className="text-xl font-bold font-mono tabular-nums text-emerald-700">{presentCount}</span>
            </div>
            <span className="text-xs font-mono font-semibold text-emerald-700">
              {totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0}%
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-rose-50/70 border border-rose-200/60 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-rose-800 font-semibold block">Absent</span>
              <span className="text-xl font-bold font-mono tabular-nums text-rose-700">{absentCount}</span>
            </div>
            <span className="text-xs font-mono font-semibold text-rose-700">
              {totalCount > 0 ? Math.round((absentCount / totalCount) * 100) : 0}%
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-amber-50/70 border border-amber-200/60 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-amber-800 font-semibold block">Late Arrival</span>
              <span className="text-xl font-bold font-mono tabular-nums text-amber-700">{lateCount}</span>
            </div>
            <span className="text-xs font-mono font-semibold text-amber-700">
              {totalCount > 0 ? Math.round((lateCount / totalCount) * 100) : 0}%
            </span>
          </div>

          <div className="col-span-2 sm:col-span-1 p-2.5 rounded-xl bg-sky-50/70 border border-sky-200/60 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-sky-800 font-semibold block">Excused</span>
              <span className="text-xl font-bold font-mono tabular-nums text-sky-700">{excusedCount}</span>
            </div>
            <span className="text-xs font-mono font-semibold text-sky-700">
              {unmarkedCount > 0 ? `${unmarkedCount} pending` : 'All marked'}
            </span>
          </div>
        </div>
      </div>

      {/* Toolbar: Batch Actions, Filters, View Modes & Keyboard Helper */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Batch 1-Click Operations */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => handleMarkAll('present')}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-semibold text-xs shadow-xs flex items-center gap-1.5 transition-all"
            >
              <CheckCheck className="w-4 h-4" />
              <span>Mark All Present</span>
            </button>
            <button
              onClick={handleMarkRemainingPresent}
              className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-semibold text-xs transition-colors flex items-center gap-1"
            >
              <span>Mark Remaining Present</span>
            </button>
            <button
              onClick={() => handleMarkAll('absent')}
              className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 font-semibold text-xs transition-colors flex items-center gap-1"
            >
              <span>Mark All Absent</span>
            </button>
            <button
              onClick={handleResetMarks}
              className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 font-medium text-xs transition-colors flex items-center gap-1"
              title="Clear all markings for this session"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset</span>
            </button>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl self-end md:self-auto">
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                setViewMode('grid');
              }}
              className={`p-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 ${
                viewMode === 'grid' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Card Grid View"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Cards</span>
            </button>
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                setViewMode('list');
              }}
              className={`p-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 ${
                viewMode === 'list' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Compact Table List View"
            >
              <List className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Table</span>
            </button>
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                setViewMode('seating');
              }}
              className={`p-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 ${
                viewMode === 'seating' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Desk Seating Arrangement View"
            >
              <Layers className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Seating</span>
            </button>
          </div>
        </div>

        {/* Filter bar and live search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2 border-t border-slate-100">
          {/* Interactive filter tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
            {(['all', 'unmarked', 'present', 'absent', 'late', 'excused'] as const).map((filter) => {
              const count =
                filter === 'all'
                  ? totalCount
                  : filter === 'unmarked'
                  ? unmarkedCount
                  : filter === 'present'
                  ? presentCount
                  : filter === 'absent'
                  ? absentCount
                  : filter === 'late'
                  ? lateCount
                  : excusedCount;

              return (
                <button
                  key={filter}
                  onClick={() => {
                    playSound('click', soundEnabled);
                    setStatusFilter(filter);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 flex items-center gap-1 ${
                    statusFilter === filter
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <span className="capitalize">{filter}</span>
                  <span className="font-mono text-[10px] opacity-75">({count})</span>
                </button>
              );
            })}
          </div>

          {/* Search bar */}
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search student or roll no..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Keyboard shortcut speed hint */}
        <div className="hidden lg:flex items-center justify-between text-[11px] text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200/50">
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-slate-700">⚡ Speed Keyboard Shortcuts:</span>
            <span>Click any student to focus, then press</span>
            <kbd className="px-1.5 py-0.5 rounded bg-white border border-slate-300 font-mono text-[10px] text-slate-800">P</kbd> Present,
            <kbd className="px-1.5 py-0.5 rounded bg-white border border-slate-300 font-mono text-[10px] text-slate-800">A</kbd> Absent,
            <kbd className="px-1.5 py-0.5 rounded bg-white border border-slate-300 font-mono text-[10px] text-slate-800">L</kbd> Late,
            <kbd className="px-1.5 py-0.5 rounded bg-white border border-slate-300 font-mono text-[10px] text-slate-800">↓</kbd> Next student
          </div>
          <span className="text-emerald-700 font-semibold">One-click auto advances!</span>
        </div>
      </div>

      {/* 🎙️ Voice Attendance Assistant (Placed prominently on the up side of the students list) */}
      <VoiceAttendanceAssistant
        classroom={classroom}
        onMarkStudent={(studentId, status) => handleMark(studentId, status)}
        soundEnabled={soundEnabled}
        currentRecords={currentRecords}
      />

      {/* Main Student Display Container */}
      {filteredStudents.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200">
          <HelpCircle className="w-10 h-10 mx-auto text-slate-400 mb-2 opacity-60" />
          <h4 className="text-sm font-bold text-slate-800">No students match current filter</h4>
          <p className="text-xs text-slate-500 mt-1">Try resetting search query or switching status filters.</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setStatusFilter('all');
            }}
            className="mt-3 px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg"
          >
            Clear Filters
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        /* Card Grid View (Touch & Tablet Optimized) */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3.5">
          {filteredStudents.map((student, idx) => {
            const rec = currentRecords[student.id];
            const status = rec?.status;
            const isFocused = focusedStudentIdx === idx;

            return (
              <div
                key={student.id}
                onClick={() => setFocusedStudentIdx(idx)}
                className={`bg-white rounded-2xl p-4 border transition-all duration-200 relative group flex flex-col justify-between ${
                  isFocused ? 'ring-2 ring-emerald-500 shadow-md' : 'shadow-xs hover:shadow-sm'
                } ${
                  status === 'present'
                    ? 'border-emerald-300 bg-emerald-50/20'
                    : status === 'absent'
                    ? 'border-rose-300 bg-rose-50/20'
                    : status === 'late'
                    ? 'border-amber-300 bg-amber-50/20'
                    : status === 'excused'
                    ? 'border-sky-300 bg-sky-50/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div>
                  {/* Top card row: Avatar, Info, Dossier view */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <StudentAvatar student={student} size="md" />
                      <div>
                        <span className="font-mono text-[11px] font-bold text-slate-500 block leading-tight">
                          {student.rollNo}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900 leading-snug line-clamp-1">{student.name}</h4>
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        playSound('click', soundEnabled);
                        setInspectStudent(student);
                      }}
                      className="p-1.5 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
                      title="Inspect Student Dossier & History"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Note preview if attached */}
                  {rec?.note && (
                    <div className="mb-3 px-2 py-1 rounded bg-amber-50 border border-amber-200 text-[11px] text-amber-900 flex items-center gap-1">
                      <MessageSquare className="w-3 h-3 shrink-0" />
                      <span className="line-clamp-1 italic">{rec.note}</span>
                    </div>
                  )}
                </div>

                {/* Tactile 1-Click Action Buttons */}
                <div className="pt-2 border-t border-slate-100">
                  <div className="grid grid-cols-2 gap-2">
                    {/* Big Present Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleMark(student.id, 'present');
                      }}
                      className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all duration-150 active:scale-95 ${
                        status === 'present'
                          ? 'bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-600/30'
                          : 'bg-slate-100 hover:bg-emerald-100 hover:text-emerald-800 text-slate-700'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>Present</span>
                    </button>

                    {/* Big Absent Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleMark(student.id, 'absent');
                      }}
                      className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all duration-150 active:scale-95 ${
                        status === 'absent'
                          ? 'bg-rose-600 text-white shadow-sm ring-2 ring-rose-600/30'
                          : 'bg-slate-100 hover:bg-rose-100 hover:text-rose-800 text-slate-700'
                      }`}
                    >
                      <X className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>Absent</span>
                    </button>
                  </div>

                  {/* Secondary states & Note action */}
                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMark(student.id, 'late');
                        }}
                        className={`px-2 py-0.5 rounded font-medium transition-colors ${
                          status === 'late'
                            ? 'bg-amber-500 text-white font-semibold'
                            : 'hover:bg-amber-100 hover:text-amber-800'
                        }`}
                      >
                        Late
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMark(student.id, 'excused');
                        }}
                        className={`px-2 py-0.5 rounded font-medium transition-colors ${
                          status === 'excused'
                            ? 'bg-sky-500 text-white font-semibold'
                            : 'hover:bg-sky-100 hover:text-sky-800'
                        }`}
                      >
                        Excused
                      </button>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setNoteStudentId(student.id);
                        setTempNoteText(rec?.note || '');
                      }}
                      className="hover:text-slate-900 text-slate-500 underline decoration-slate-300 hover:decoration-slate-600 transition-colors"
                    >
                      {rec?.note ? 'Edit note' : '+ note'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : viewMode === 'list' ? (
        /* Compact Table List View */
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4 w-16">Roll No</th>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Current Status</th>
                <th className="py-3 px-4 text-center">1-Click Fast Mark</th>
                <th className="py-3 px-4">Remark / Note</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredStudents.map((student, idx) => {
                const rec = currentRecords[student.id];
                const status = rec?.status;
                const isFocused = focusedStudentIdx === idx;

                return (
                  <tr
                    key={student.id}
                    onClick={() => setFocusedStudentIdx(idx)}
                    className={`hover:bg-slate-50 transition-colors cursor-pointer ${
                      isFocused ? 'bg-emerald-50/40' : ''
                    }`}
                  >
                    <td className="py-3 px-4 font-mono font-bold text-slate-600">{student.rollNo}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <StudentAvatar student={student} size="xs" />
                        <span className="font-bold text-slate-900">{student.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      {status ? (
                        <span
                          className={`inline-flex items-center gap-1 font-semibold capitalize px-2 py-0.5 rounded text-[11px] ${
                            status === 'present'
                              ? 'text-emerald-700 bg-emerald-50'
                              : status === 'absent'
                              ? 'text-rose-700 bg-rose-50'
                              : status === 'late'
                              ? 'text-amber-700 bg-amber-50'
                              : 'text-sky-700 bg-sky-50'
                          }`}
                        >
                          {status === 'present' && <Check className="w-3 h-3 stroke-[2.5]" />}
                          {status === 'absent' && <X className="w-3 h-3 stroke-[2.5]" />}
                          {status === 'late' && <Clock className="w-3 h-3" />}
                          {status === 'excused' && <ShieldCheck className="w-3 h-3" />}
                          {status}
                        </span>
                      ) : (
                        <span className="text-slate-400 font-mono text-[11px]">Unmarked</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleMark(student.id, 'present');
                          }}
                          className={`px-3 py-1 rounded-lg font-bold text-xs flex items-center gap-1 transition-all ${
                            status === 'present'
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'hover:bg-white text-slate-700'
                          }`}
                        >
                          <Check className="w-3 h-3" />
                          <span>P</span>
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleMark(student.id, 'absent');
                          }}
                          className={`px-3 py-1 rounded-lg font-bold text-xs flex items-center gap-1 transition-all ${
                            status === 'absent'
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'hover:bg-white text-slate-700'
                          }`}
                        >
                          <X className="w-3 h-3" />
                          <span>A</span>
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleMark(student.id, 'late');
                          }}
                          className={`px-2 py-1 rounded-lg font-medium text-xs transition-all ${
                            status === 'late'
                              ? 'bg-amber-500 text-white shadow-xs'
                              : 'hover:bg-white text-slate-600'
                          }`}
                        >
                          L
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleMark(student.id, 'excused');
                          }}
                          className={`px-2 py-1 rounded-lg font-medium text-xs transition-all ${
                            status === 'excused'
                              ? 'bg-sky-500 text-white shadow-xs'
                              : 'hover:bg-white text-slate-600'
                          }`}
                        >
                          E
                        </button>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {rec?.note ? (
                        <span className="text-[11px] italic bg-slate-100 px-2 py-0.5 rounded text-slate-800">
                          {rec.note}
                        </span>
                      ) : (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setNoteStudentId(student.id);
                            setTempNoteText('');
                          }}
                          className="text-[11px] text-slate-400 hover:text-slate-700 underline"
                        >
                          + add remark
                        </button>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setInspectStudent(student);
                        }}
                        className="px-2.5 py-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors font-medium text-xs"
                      >
                        Profile
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        /* Seating Chart View */
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
          <div className="mb-6 p-3 rounded-xl bg-slate-100/80 border border-slate-200 text-center font-bold text-xs uppercase tracking-wider text-slate-600">
            Teacher's Podium / Whiteboard Front
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {classroom.students.map((student) => {
              const rec = currentRecords[student.id];
              const status = rec?.status;

              return (
                <div
                  key={student.id}
                  onClick={() => handleMark(student.id, status === 'present' ? 'absent' : 'present')}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer select-none text-center ${
                    status === 'present'
                      ? 'bg-emerald-50 border-emerald-300 ring-2 ring-emerald-500/20'
                      : status === 'absent'
                      ? 'bg-rose-50 border-rose-300 ring-2 ring-rose-500/20'
                      : status === 'late'
                      ? 'bg-amber-50 border-amber-300'
                      : status === 'excused'
                      ? 'bg-sky-50 border-sky-300'
                      : 'bg-slate-50 border-dashed border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  <div className="text-[10px] font-mono text-slate-500 font-semibold mb-1">
                    {student.rollNo}
                  </div>
                  <div className="mb-1.5 flex justify-center">
                    <StudentAvatar student={student} size="md" />
                  </div>
                  <div className="font-bold text-xs text-slate-900 truncate">{student.name}</div>
                  <div className="mt-2">
                    <span
                      className={`inline-block font-semibold text-[10px] px-2 py-0.5 rounded uppercase tracking-wider ${
                        status === 'present'
                          ? 'bg-emerald-600 text-white'
                          : status === 'absent'
                          ? 'bg-rose-600 text-white'
                          : status === 'late'
                          ? 'bg-amber-500 text-white'
                          : status === 'excused'
                          ? 'bg-sky-500 text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {status || 'Click to Mark'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Sticky Bottom Completion & Save Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 px-4 py-3 shadow-lg">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-4 text-xs">
            <div>
              <span className="text-slate-500">Roll Call Progress:</span>{' '}
              <span className="font-bold font-mono text-slate-900">
                {markedCount} / {totalCount} Students
              </span>{' '}
              <span
                className={`font-semibold ml-1 ${
                  isComplete ? 'text-emerald-600' : 'text-amber-600'
                }`}
              >
                ({Math.round((markedCount / Math.max(1, totalCount)) * 100)}%)
              </span>
            </div>

            <div className="hidden sm:block w-36 bg-slate-200 rounded-full h-2 overflow-hidden">
              <div
                className={`h-full transition-all duration-300 rounded-full ${
                  isComplete ? 'bg-emerald-500' : 'bg-amber-500'
                }`}
                style={{ width: `${(markedCount / Math.max(1, totalCount)) * 100}%` }}
              />
            </div>

            {absentCount > 0 && (
              <span className="text-rose-600 font-semibold hidden md:inline">
                ⚠️ {absentCount} {absentCount === 1 ? 'student' : 'students'} marked absent
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            {justSavedNotice && (
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg flex items-center gap-1 animate-fade-in">
                <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                Saved to Register!
              </span>
            )}

            <button
              onClick={handleSave}
              className="py-2.5 px-6 rounded-xl bg-slate-900 hover:bg-slate-800 active:scale-95 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2"
            >
              <Save className="w-4 h-4 text-emerald-400" />
              <span>Save & Complete Roll Call</span>
            </button>
          </div>
        </div>
      </div>

      {/* Note Attachment Modal */}
      {noteStudentId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xl max-w-sm w-full">
            <h4 className="font-bold text-sm text-slate-900 mb-1">Add Note / Reason</h4>
            <p className="text-xs text-slate-500 mb-3">
              Attach an explanation or excuse for this student's attendance status.
            </p>
            <textarea
              autoFocus
              rows={3}
              value={tempNoteText}
              onChange={(e) => setTempNoteText(e.target.value)}
              placeholder="e.g. Arrived 15 mins late due to bus traffic, fever note submitted..."
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 mb-3"
            />
            <div className="flex justify-end gap-2 text-xs">
              <button
                onClick={() => setNoteStudentId(null)}
                className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 font-medium hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setCurrentRecords((prev) => ({
                    ...prev,
                    [noteStudentId]: {
                      ...prev[noteStudentId],
                      status: prev[noteStudentId]?.status || 'present',
                      note: tempNoteText.trim() || undefined,
                    },
                  }));
                  playSound('click', soundEnabled);
                  setNoteStudentId(null);
                }}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 text-white font-semibold hover:bg-emerald-700"
              >
                Save Note
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Student Dossier Modal */}
      <StudentDossierModal
        student={inspectStudent}
        classId={classroom.id}
        sessions={sessions}
        onClose={() => setInspectStudent(null)}
        soundEnabled={soundEnabled}
        onUpdateStudent={(updatedStudent) => {
          if (onUpdateClassroom) {
            const updatedStudents = classroom.students.map((st) =>
              st.id === updatedStudent.id ? updatedStudent : st
            );
            onUpdateClassroom({
              ...classroom,
              students: updatedStudents,
            });
          }
          setInspectStudent(updatedStudent);
        }}
      />

      {/* Random Student Selector Modal */}
      {showRandomPicker && (
        <RandomPickerModal
          students={classroom.students}
          onClose={() => setShowRandomPicker(false)}
          soundEnabled={soundEnabled}
        />
      )}
    </div>
  );
};
