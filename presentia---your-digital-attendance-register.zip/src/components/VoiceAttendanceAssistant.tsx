import React, { useState, useEffect, useRef } from 'react';
import { Classroom, AttendanceStatus, Student } from '../types/attendance';
import { playSound } from '../utils/audio';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldCheck,
  AlertCircle,
  HelpCircle,
  Radio,
  RotateCcw,
} from 'lucide-react';

interface VoiceAttendanceAssistantProps {
  classroom: Classroom;
  onMarkStudent: (studentId: string, status: AttendanceStatus) => void;
  soundEnabled: boolean;
  currentRecords: Record<string, { status: AttendanceStatus; note?: string }>;
}

interface VoiceLog {
  id: string;
  studentName: string;
  rollNo: string;
  status: AttendanceStatus;
  rawTranscript: string;
  timestamp: string;
}

export const VoiceAttendanceAssistant: React.FC<VoiceAttendanceAssistantProps> = ({
  classroom,
  onMarkStudent,
  soundEnabled,
  currentRecords,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [lastActionNotice, setLastActionNotice] = useState<{
    text: string;
    type: 'success' | 'warn' | 'info';
  } | null>(null);
  const [voiceLogs, setVoiceLogs] = useState<VoiceLog[]>([]);
  const [speakConfirmation, setSpeakConfirmation] = useState(true);
  const [showGuide, setShowGuide] = useState(false);
  const [micSupported, setMicSupported] = useState(true);

  const recognitionRef = useRef<any>(null);
  const isListeningRef = useRef(false);

  // Text-To-Speech Speaker confirmation
  const speakFeedback = (text: string) => {
    if (!speakConfirmation || typeof window === 'undefined' || !window.speechSynthesis) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    } catch {
      // Graceful fallback if speech synthesis is blocked
    }
  };

  // Fuzzy match student by spoken name or roll number
  const matchStudent = (spokenText: string): Student | null => {
    const cleanSpoken = spokenText.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').trim();

    // 1. Exact full name match
    for (const st of classroom.students) {
      const lowerName = st.name.toLowerCase();
      if (cleanSpoken.includes(lowerName)) {
        return st;
      }
    }

    // 2. Check roll number match (e.g. "10A-02" or "roll number 2" or "number 2")
    for (const st of classroom.students) {
      const rollParts = st.rollNo.toLowerCase().replace(/[^a-z0-9]/g, '');
      const spokenNoSpaces = cleanSpoken.replace(/\s+/g, '');
      if (spokenNoSpaces.includes(rollParts)) {
        return st;
      }
      // Check last digits e.g. "02" or "2"
      const digitsMatch = st.rollNo.match(/\d+$/);
      if (digitsMatch) {
        const num = digitsMatch[0];
        const numClean = parseInt(num, 10);
        if (
          cleanSpoken.includes(`roll ${numClean}`) ||
          cleanSpoken.includes(`roll number ${numClean}`) ||
          cleanSpoken.includes(`number ${numClean}`) ||
          cleanSpoken.includes(`student ${numClean}`)
        ) {
          return st;
        }
      }
    }

    // 3. First name or Last name match
    for (const st of classroom.students) {
      const nameParts = st.name.toLowerCase().split(/\s+/);
      for (const part of nameParts) {
        if (part.length >= 3 && cleanSpoken.split(/\s+/).includes(part)) {
          return st;
        }
      }
    }

    // 4. Substring / partial match on words
    for (const st of classroom.students) {
      const nameWords = st.name.toLowerCase().split(/\s+/);
      for (const word of nameWords) {
        if (word.length >= 4 && cleanSpoken.includes(word)) {
          return st;
        }
      }
    }

    return null;
  };

  // Determine spoken attendance status
  const extractStatus = (spokenText: string): AttendanceStatus | null => {
    const text = spokenText.toLowerCase();

    // Check absent first (avoids "present" inside other words)
    if (
      text.includes('absent') ||
      text.includes('not here') ||
      text.includes('missing') ||
      text.includes('skip')
    ) {
      return 'absent';
    }

    if (
      text.includes('present') ||
      text.includes('here') ||
      text.includes('attending') ||
      text.includes('yes')
    ) {
      return 'present';
    }

    if (
      text.includes('late') ||
      text.includes('tardy') ||
      text.includes('delayed')
    ) {
      return 'late';
    }

    if (
      text.includes('excused') ||
      text.includes('leave') ||
      text.includes('medical') ||
      text.includes('sick')
    ) {
      return 'excused';
    }

    return null;
  };

  // Process incoming spoken sentence
  const processVoiceCommand = (rawSpeech: string) => {
    const status = extractStatus(rawSpeech);
    const matched = matchStudent(rawSpeech);

    if (matched && status) {
      // Mark student
      onMarkStudent(matched.id, status);
      playSound(status, soundEnabled);

      const statusLabel =
        status === 'present'
          ? 'Present'
          : status === 'absent'
          ? 'Absent'
          : status === 'late'
          ? 'Late'
          : 'Excused';

      // Voice confirmation feedback
      speakFeedback(`${matched.name}, ${statusLabel}`);

      setLastActionNotice({
        text: `Marked ${matched.name} (${matched.rollNo}) as ${statusLabel}`,
        type: 'success',
      });

      // Append to voice logs
      const newLog: VoiceLog = {
        id: `log_${Date.now()}_${Math.random()}`,
        studentName: matched.name,
        rollNo: matched.rollNo,
        status,
        rawTranscript: rawSpeech,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      };
      setVoiceLogs((prev) => [newLog, ...prev.slice(0, 9)]);
    } else if (status && !matched) {
      setLastActionNotice({
        text: `Heard status "${status}", but could not identify student name. Try: "Beatrix Vance ${status}"`,
        type: 'warn',
      });
    } else if (matched && !status) {
      setLastActionNotice({
        text: `Identified ${matched.name}. Please say "Present" or "Absent".`,
        type: 'info',
      });
    } else {
      setLastActionNotice({
        text: `Could not match: "${rawSpeech}". Say: "[Student Name] Present" or "[Student Name] Absent"`,
        type: 'warn',
      });
    }
  };

  // Initialize Speech Recognition
  const startRecognition = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setMicSupported(false);
      setLastActionNotice({
        text: 'Speech recognition API is not supported in this browser. Use Chrome, Edge, or Safari, or click the voice simulator below.',
        type: 'warn',
      });
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        isListeningRef.current = true;
        playSound('click', soundEnabled);
        setLastActionNotice({
          text: 'Microphone active! Speak: "[Student Name] Present" or "[Student Name] Absent"',
          type: 'info',
        });
      };

      recognition.onresult = (event: any) => {
        let finalPhrase = '';
        let interimPhrase = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalPhrase += event.results[i][0].transcript;
          } else {
            interimPhrase += event.results[i][0].transcript;
          }
        }

        const currentText = (finalPhrase || interimPhrase).trim();
        setTranscript(currentText);

        if (finalPhrase.trim()) {
          processVoiceCommand(finalPhrase.trim());
          setTranscript('');
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error === 'no-speech') return;
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          setIsListening(false);
          isListeningRef.current = false;
          setLastActionNotice({
            text: 'Microphone permission denied. Please allow microphone access in browser settings.',
            type: 'warn',
          });
        }
      };

      recognition.onend = () => {
        // Auto-restart if teacher didn't explicitly stop it
        if (isListeningRef.current) {
          try {
            recognition.start();
          } catch {
            setIsListening(false);
            isListeningRef.current = false;
          }
        } else {
          setIsListening(false);
        }
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error('Failed to start speech recognition:', err);
      setIsListening(false);
      isListeningRef.current = false;
      setLastActionNotice({
        text: 'Unable to start microphone. Please check browser permissions.',
        type: 'warn',
      });
    }
  };

  const stopRecognition = () => {
    isListeningRef.current = false;
    setIsListening(false);
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
    }
    playSound('click', soundEnabled);
    setTranscript('');
    setLastActionNotice({
      text: 'Microphone stopped.',
      type: 'info',
    });
  };

  const toggleListening = () => {
    if (isListening) {
      stopRecognition();
    } else {
      startRecognition();
    }
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      isListeningRef.current = false;
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
    };
  }, []);

  return (
    <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-4 sm:p-5 shadow-lg border border-indigo-900/40 space-y-4">
      {/* Top row: Microphone Controller & Speaker Settings */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {/* Main Toggle Mic Button */}
          <button
            onClick={toggleListening}
            className={`relative px-5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 ${
              isListening
                ? 'bg-rose-600 hover:bg-rose-700 text-white ring-4 ring-rose-500/30'
                : 'bg-emerald-500 hover:bg-emerald-600 text-white'
            }`}
          >
            {isListening ? (
              <>
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75" />
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-white" />
                </span>
                <MicOff className="w-4 h-4" />
                <span>Stop Listening</span>
              </>
            ) : (
              <>
                <Mic className="w-4 h-4" />
                <span>Start Microphone</span>
              </>
            )}
          </button>

          {/* Audio Visualizer wave if active */}
          {isListening ? (
            <div className="flex items-center gap-1 px-3 py-2 bg-indigo-900/60 rounded-xl border border-indigo-700/50">
              <span className="w-1 h-3.5 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
              <span className="w-1 h-5 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
              <span className="w-1 h-6 bg-emerald-300 rounded-full animate-bounce" />
              <span className="w-1 h-4 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.2s]" />
              <span className="w-1 h-3 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.35s]" />
              <span className="text-[11px] font-mono text-emerald-300 ml-1.5 font-semibold">
                Listening Live...
              </span>
            </div>
          ) : (
            <span className="text-xs text-slate-400 hidden sm:inline">
              Tap mic to mark attendance by speaking student names.
            </span>
          )}
        </div>

        {/* Right Controls: Speaker Feedback & Voice Command Guide */}
        <div className="flex items-center gap-2.5 self-end md:self-auto">
          {/* Audio Speaker Response Toggle */}
          <button
            onClick={() => {
              setSpeakConfirmation((prev) => !prev);
              playSound('click', soundEnabled);
            }}
            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              speakConfirmation
                ? 'bg-indigo-900/70 border-indigo-500/50 text-indigo-200'
                : 'bg-slate-800/80 border-slate-700 text-slate-400'
            }`}
            title="Toggle spoken voice confirmation (Speaker)"
          >
            {speakConfirmation ? (
              <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <VolumeX className="w-3.5 h-3.5 text-slate-400" />
            )}
            <span>Speaker: {speakConfirmation ? 'ON' : 'OFF'}</span>
          </button>

          {/* Quick Voice Guide Button */}
          <button
            onClick={() => setShowGuide((prev) => !prev)}
            className="px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1 transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
            <span>Voice Guide</span>
          </button>
        </div>
      </div>

      {/* Live Hearing Transcript Display */}
      {transcript && (
        <div className="bg-indigo-950/90 border border-indigo-500/40 rounded-xl px-3.5 py-2 flex items-center gap-2 animate-fade-in">
          <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse shrink-0" />
          <span className="text-xs text-indigo-300 font-medium">Hearing:</span>
          <span className="text-xs font-mono font-bold text-white tracking-wide">"{transcript}"</span>
        </div>
      )}

      {/* Action Notice feedback banner */}
      {lastActionNotice && (
        <div
          className={`px-3.5 py-2 rounded-xl text-xs font-medium flex items-center justify-between gap-2 animate-fade-in ${
            lastActionNotice.type === 'success'
              ? 'bg-emerald-950/80 border border-emerald-500/40 text-emerald-200'
              : lastActionNotice.type === 'warn'
              ? 'bg-amber-950/80 border border-amber-500/40 text-amber-200'
              : 'bg-slate-800/90 border border-slate-700 text-slate-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {lastActionNotice.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : lastActionNotice.type === 'warn' ? (
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            ) : (
              <Sparkles className="w-4 h-4 text-indigo-400 shrink-0" />
            )}
            <span>{lastActionNotice.text}</span>
          </div>

          <button
            onClick={() => setLastActionNotice(null)}
            className="text-slate-400 hover:text-white"
          >
            <XCircle className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Expandable Voice Guide & Quick Simulator */}
      {showGuide && (
        <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-3 text-xs animate-fade-in">
          <div className="flex items-center justify-between">
            <span className="font-bold text-white uppercase tracking-wider text-[11px]">
              How to Speak Attendance Commands:
            </span>
            <button
              onClick={() => setShowGuide(false)}
              className="text-slate-400 hover:text-white text-xs"
            >
              Close
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
            <div className="p-2.5 bg-slate-900/70 rounded-lg border border-slate-700">
              <span className="text-emerald-400 font-bold block mb-1">To Mark Present:</span>
              <p className="text-slate-300 font-mono text-[11px]">
                "Beatrix Vance Present"
                <br />
                "Alexander Present"
                <br />
                "Carlos is here"
              </p>
            </div>

            <div className="p-2.5 bg-slate-900/70 rounded-lg border border-slate-700">
              <span className="text-rose-400 font-bold block mb-1">To Mark Absent:</span>
              <p className="text-slate-300 font-mono text-[11px]">
                "Daphne Sterling Absent"
                <br />
                "Ethan Absent"
                <br />
                "Fiona is not here"
              </p>
            </div>

            <div className="p-2.5 bg-slate-900/70 rounded-lg border border-slate-700">
              <span className="text-amber-400 font-bold block mb-1">To Mark Late:</span>
              <p className="text-slate-300 font-mono text-[11px]">
                "Marcus Brody Late"
                <br />
                "Isaac Campbell Tardy"
              </p>
            </div>

            <div className="p-2.5 bg-slate-900/70 rounded-lg border border-slate-700">
              <span className="text-sky-400 font-bold block mb-1">By Roll Number:</span>
              <p className="text-slate-300 font-mono text-[11px]">
                "Roll 2 Present"
                <br />
                "Number 4 Absent"
              </p>
            </div>
          </div>

          {/* Quick Voice Command Simulator for instant testing */}
          <div className="pt-2 border-t border-slate-700/60 flex flex-wrap items-center gap-2">
            <span className="text-slate-400 text-[11px] font-medium">Test Instant Voice Trigger:</span>
            {classroom.students.slice(0, 4).map((st) => (
              <div key={st.id} className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => processVoiceCommand(`${st.name} present`)}
                  className="px-2 py-0.5 rounded bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/50 text-[10px] font-mono"
                >
                  "{st.name.split(' ')[0]} Present"
                </button>
                <button
                  type="button"
                  onClick={() => processVoiceCommand(`${st.name} absent`)}
                  className="px-2 py-0.5 rounded bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-700/50 text-[10px] font-mono"
                >
                  "Absent"
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Spoken Logs Carousel (last 4 processed) */}
      {voiceLogs.length > 0 && (
        <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-400 text-[11px] font-medium shrink-0">Recent Spoken:</span>
          {voiceLogs.slice(0, 4).map((log) => (
            <div
              key={log.id}
              className={`px-2.5 py-1 rounded-lg border text-[11px] flex items-center gap-1.5 font-medium ${
                log.status === 'present'
                  ? 'bg-emerald-950/50 border-emerald-500/30 text-emerald-300'
                  : log.status === 'absent'
                  ? 'bg-rose-950/50 border-rose-500/30 text-rose-300'
                  : log.status === 'late'
                  ? 'bg-amber-950/50 border-amber-500/30 text-amber-300'
                  : 'bg-sky-950/50 border-sky-500/30 text-sky-300'
              }`}
            >
              <span>{log.studentName}</span>
              <span className="font-bold uppercase text-[10px]">
                {log.status === 'present' ? '✓ P' : log.status === 'absent' ? '✗ A' : log.status}
              </span>
              <span className="text-[9px] opacity-60 font-mono">{log.timestamp}</span>
            </div>
          ))}

          <button
            onClick={() => setVoiceLogs([])}
            className="text-[10px] text-slate-500 hover:text-slate-300 underline ml-auto"
          >
            Clear logs
          </button>
        </div>
      )}
    </div>
  );
};
