import { Logo, LogoVariant } from './Logo';
import { Classroom, ViewTab } from '../types/attendance';
import { Volume2, VolumeX, Sparkles } from 'lucide-react';
import { playSound } from '../utils/audio';

interface TopNavProps {
  currentTab: ViewTab;
  onSelectTab: (tab: ViewTab) => void;
  selectedClass: Classroom;
  classes: Classroom[];
  onSelectClass: (c: Classroom) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  logoVariant?: LogoVariant;
  onCycleLogo?: () => void;
  onPlayLogoIntro?: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentTab,
  onSelectTab,
  selectedClass,
  classes,
  onSelectClass,
  soundEnabled,
  onToggleSound,
  logoVariant = 'official',
  onCycleLogo,
  onPlayLogoIntro,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single element Brand Zone */}
          <div className="shrink-0 flex items-center gap-3">
            <Logo
              size="md"
              variant={logoVariant}
              soundEnabled={soundEnabled}
              onClick={() => {
                if (onPlayLogoIntro) {
                  onPlayLogoIntro();
                } else if (onCycleLogo) {
                  onCycleLogo();
                } else {
                  onSelectTab('mark');
                }
              }}
            />
            {onPlayLogoIntro && (
              <button
                onClick={onPlayLogoIntro}
                className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 border border-sky-200/80 rounded-full transition-all shadow-xs hover:scale-105 active:scale-95"
                title="Play animation: Glass Shatter & Logo Forging representation"
              >
                <Sparkles className="w-3 h-3 text-sky-600 animate-pulse" />
                <span>Logo Animation</span>
              </button>
            )}
          </div>

          {/* Zone 2: 4-5 concise single-line nav links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                onSelectTab('mark');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'mark'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Mark Attendance
            </button>
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                onSelectTab('history');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'history'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              History & Heatmap
            </button>
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                onSelectTab('analytics');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'analytics'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Student Analytics
            </button>
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                onSelectTab('reports');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'reports'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Reports & Export
            </button>
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                onSelectTab('classes');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'classes'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Class Roster
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action + Quick Controls */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Quick Class Selector */}
            <div className="relative inline-block">
              <select
                value={selectedClass.id}
                onChange={(e) => {
                  const found = classes.find((c) => c.id === e.target.value);
                  if (found) {
                    playSound('click', soundEnabled);
                    onSelectClass(found);
                  }
                }}
                className="bg-slate-100 border border-slate-200 text-slate-800 text-xs font-medium rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                aria-label="Select active classroom"
              >
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.code})
                  </option>
                ))}
              </select>
            </div>

            {/* Sound Mute/Unmute */}
            <button
              onClick={onToggleSound}
              className={`p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors ${
                !soundEnabled ? 'opacity-60' : ''
              }`}
              title={soundEnabled ? 'Audio Feedback Enabled (Click to Mute)' : 'Audio Feedback Muted'}
              aria-label="Toggle sound feedback"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-600" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Primary Action Button */}
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                onSelectTab('mark');
              }}
              className="px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 transition-all rounded-lg shadow-sm flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Take Attendance</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex items-center gap-2 overflow-x-auto py-2 border-t border-slate-100">
          <button
            onClick={() => onSelectTab('mark')}
            className={`px-3 py-1 text-xs font-medium rounded whitespace-nowrap ${
              currentTab === 'mark' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Mark
          </button>
          <button
            onClick={() => onSelectTab('history')}
            className={`px-3 py-1 text-xs font-medium rounded whitespace-nowrap ${
              currentTab === 'history' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            History
          </button>
          <button
            onClick={() => onSelectTab('analytics')}
            className={`px-3 py-1 text-xs font-medium rounded whitespace-nowrap ${
              currentTab === 'analytics' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Analytics
          </button>
          <button
            onClick={() => onSelectTab('reports')}
            className={`px-3 py-1 text-xs font-medium rounded whitespace-nowrap ${
              currentTab === 'reports' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Reports
          </button>
          <button
            onClick={() => onSelectTab('classes')}
            className={`px-3 py-1 text-xs font-medium rounded whitespace-nowrap ${
              currentTab === 'classes' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Classes
          </button>
        </div>
      </div>
    </header>
  );
};
