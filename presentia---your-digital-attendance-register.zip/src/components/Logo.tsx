import React from 'react';
import { playSound } from '../utils/audio';

export type LogoVariant = 'official' | 'monogram' | 'shield' | 'folio';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  className?: string;
  onClick?: () => void;
  soundEnabled?: boolean;
  variant?: LogoVariant;
  fullBanner?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showTagline = true,
  className = '',
  onClick,
  soundEnabled = true,
  variant = 'official',
  fullBanner = false,
}) => {
  const handleClick = () => {
    playSound('click', soundEnabled);
    if (onClick) onClick();
  };

  // If user requests the full wide brand banner
  if (fullBanner) {
    return (
      <div
        onClick={handleClick}
        className={`group relative rounded-2xl overflow-hidden border border-slate-700/80 shadow-md bg-slate-950 cursor-pointer transition-all hover:shadow-lg ${className}`}
        title="Presentia - Your Digital Attendance Register"
      >
        <img
          src="/assets/presentia_dark_logo.jpg"
          alt="Presentia - Your Digital Attendance Register"
          className="w-full h-auto object-cover max-h-48 transition-transform duration-500 group-hover:scale-[1.02]"
          onError={(e) => {
            (e.target as HTMLImageElement).src = '/assets/presentia_logo.jpg';
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/10 to-transparent pointer-events-none" />
      </div>
    );
  }

  const dims = {
    sm: { icon: 34, text: 'text-lg', badge: 'text-[10px]' },
    md: { icon: 42, text: 'text-xl', badge: 'text-[11px]' },
    lg: { icon: 54, text: 'text-2xl', badge: 'text-xs' },
    xl: { icon: 70, text: 'text-3xl', badge: 'text-sm' },
  }[size];

  return (
    <div
      onClick={handleClick}
      className={`inline-flex items-center gap-3 cursor-pointer group select-none transition-transform duration-200 active:scale-95 ${className}`}
      title="Presentia - Your Digital Attendance Register"
    >
      {/* Emblem Icon */}
      <div className="relative shrink-0 flex items-center justify-center">
        {variant === 'official' && (
          /* Official Brand Emblem from user uploaded dark asset */
          <div
            className="relative rounded-xl overflow-hidden shadow-sm ring-1 ring-sky-400/50 bg-slate-950 flex items-center justify-center group-hover:ring-sky-400 group-hover:shadow-md transition-all duration-300"
            style={{ width: dims.icon, height: dims.icon }}
          >
            <img
              src="/assets/presentia_icon.png"
              alt="Presentia Emblem"
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/assets/presentia_dark_logo.jpg';
              }}
            />
            {/* Subtle gloss reflection overlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-sky-500/15 via-transparent to-white/20 pointer-events-none" />
          </div>
        )}

        {variant === 'monogram' && (
          /* Style 2: Monogram P + Checkmark Ribbon */
          <svg
            width={dims.icon}
            height={dims.icon}
            viewBox="0 0 64 64"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="transition-all duration-300 group-hover:scale-105 filter drop-shadow-md"
          >
            <rect
              x="6"
              y="6"
              width="52"
              height="52"
              rx="16"
              fill="url(#pCardGrad)"
              stroke="url(#pBorderGrad)"
              strokeWidth="1.5"
            />
            <rect
              x="18"
              y="16"
              width="7.5"
              height="32"
              rx="3.75"
              fill="url(#pPillarGrad)"
            />
            <path
              d="M23 20H34C39.5228 20 44 24.4772 44 30C44 35.5228 39.5228 40 34 40H28"
              stroke="url(#pLoopGrad)"
              strokeWidth="5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M24 33L32 41L47 17"
              stroke="url(#pCheckGrad)"
              strokeWidth="5.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <defs>
              <linearGradient id="pCardGrad" x1="6" y1="6" x2="58" y2="58" gradientUnits="userSpaceOnUse">
                <stop stopColor="#0F172A" />
                <stop offset="1" stopColor="#022C22" />
              </linearGradient>
              <linearGradient id="pBorderGrad" x1="6" y1="6" x2="58" y2="58" gradientUnits="userSpaceOnUse">
                <stop stopColor="#334155" />
                <stop offset="0.5" stopColor="#059669" />
                <stop offset="1" stopColor="#1E293B" />
              </linearGradient>
              <linearGradient id="pPillarGrad" x1="18" y1="16" x2="25.5" y2="48" gradientUnits="userSpaceOnUse">
                <stop stopColor="#64748B" />
                <stop offset="1" stopColor="#334155" />
              </linearGradient>
              <linearGradient id="pLoopGrad" x1="23" y1="20" x2="44" y2="40" gradientUnits="userSpaceOnUse">
                <stop stopColor="#10B981" />
                <stop offset="0.6" stopColor="#059669" />
                <stop offset="1" stopColor="#047857" />
              </linearGradient>
              <linearGradient id="pCheckGrad" x1="24" y1="17" x2="47" y2="41" gradientUnits="userSpaceOnUse">
                <stop stopColor="#34D399" />
                <stop offset="0.5" stopColor="#10B981" />
                <stop offset="1" stopColor="#059669" />
              </linearGradient>
            </defs>
          </svg>
        )}

        {variant === 'shield' && (
          /* Style 3: Academic Shield & Golden Laurel Check */
          <svg
            width={dims.icon}
            height={dims.icon}
            viewBox="0 0 64 64"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="transition-all duration-300 group-hover:scale-105 filter drop-shadow-md"
          >
            <path
              d="M32 8L50 14V32C50 43.5 42 52.5 32 56C22 52.5 14 43.5 14 32V14L32 8Z"
              fill="url(#shieldFill)"
              stroke="url(#shieldStroke)"
              strokeWidth="2"
            />
            <path
              d="M24 32L30 38L42 22"
              stroke="#10B981"
              strokeWidth="4.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <circle cx="32" cy="18" r="2.5" fill="#F59E0B" />
            <defs>
              <linearGradient id="shieldFill" x1="14" y1="8" x2="50" y2="56" gradientUnits="userSpaceOnUse">
                <stop stopColor="#0F172A" />
                <stop offset="1" stopColor="#1E293B" />
              </linearGradient>
              <linearGradient id="shieldStroke" x1="14" y1="8" x2="50" y2="56" gradientUnits="userSpaceOnUse">
                <stop stopColor="#10B981" />
                <stop offset="1" stopColor="#3B82F6" />
              </linearGradient>
            </defs>
          </svg>
        )}

        {variant === 'folio' && (
          /* Style 4: Digital Register Folio */
          <svg
            width={dims.icon}
            height={dims.icon}
            viewBox="0 0 64 64"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="transition-all duration-300 group-hover:scale-105 filter drop-shadow-md"
          >
            <rect x="10" y="12" width="44" height="40" rx="10" fill="#0F172A" stroke="#10B981" strokeWidth="2" />
            <line x1="18" y1="22" x2="30" y2="22" stroke="#64748B" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="18" y1="30" x2="26" y2="30" stroke="#64748B" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="18" y1="38" x2="28" y2="38" stroke="#64748B" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M28 34L35 41L48 20" stroke="#10B981" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
      </div>

      {/* Brand Name Typography */}
      <div className="flex flex-col leading-none">
        <div className="flex items-center gap-1.5">
          <span className={`font-extrabold tracking-tight text-[#164e87] ${dims.text}`}>
            present<span className="text-[#0284c7]">ia</span>
          </span>
          {/* Subtle cybernetic checkmark badge matching official logo */}
          <span className="inline-flex items-center justify-center w-4 h-4 rounded-full bg-sky-100 text-sky-700 text-[10px] font-black group-hover:bg-sky-600 group-hover:text-white transition-colors">
            ✓
          </span>
        </div>
        {showTagline && (
          <div className="flex items-center gap-1 mt-0.5">
            <span className={`font-medium tracking-normal text-[#1e3a8a]/70 group-hover:text-[#1e3a8a] transition-colors ${dims.badge}`}>
              your digital attendance register
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
