import React, { useRef } from 'react';
import { Camera, User, Trash2 } from 'lucide-react';

interface StudentAvatarProps {
  student: {
    name: string;
    avatarColor?: string;
    photoUrl?: string;
  };
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  editable?: boolean;
  onPhotoChange?: (photoUrl: string | undefined) => void;
}

export const PRESET_AVATARS = [
  'https://api.dicebear.com/7.x/bottts/svg?seed=Felix',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Alex',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Bella',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Carlos',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Daisy',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Ethan',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Fiona',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=George',
];

export const StudentAvatar: React.FC<StudentAvatarProps> = ({
  student,
  size = 'md',
  className = '',
  editable = false,
  onPhotoChange,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sizeClasses = {
    xs: 'w-6 h-6 text-[10px] rounded-md',
    sm: 'w-8 h-8 text-xs rounded-lg',
    md: 'w-10 h-10 text-sm rounded-xl',
    lg: 'w-14 h-14 text-base rounded-2xl',
    xl: 'w-20 h-20 text-xl rounded-2xl',
  }[size];

  const initials = student.name
    ? student.name
        .split(' ')
        .filter(Boolean)
        .map((n) => n[0])
        .slice(0, 2)
        .join('')
        .toUpperCase()
    : '?';

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onPhotoChange) return;

    // Convert to compressed base64 data URL
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_DIM = 240;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > MAX_DIM) {
            height = Math.round((height * MAX_DIM) / width);
            width = MAX_DIM;
          }
        } else {
          if (height > MAX_DIM) {
            width = Math.round((width * MAX_DIM) / height);
            height = MAX_DIM;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          onPhotoChange(dataUrl);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className={`relative shrink-0 select-none group inline-block ${className}`}>
      <div
        className={`overflow-hidden flex items-center justify-center font-bold text-white shadow-xs transition-transform ${sizeClasses}`}
        style={{ backgroundColor: student.avatarColor || '#2563EB' }}
      >
        {student.photoUrl ? (
          <img
            src={student.photoUrl}
            alt={student.name}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
            onError={(e) => {
              // Fallback to initials if image fails
              (e.currentTarget as HTMLElement).style.display = 'none';
            }}
          />
        ) : (
          <span>{initials}</span>
        )}
      </div>

      {/* Editable Overlay */}
      {editable && (
        <>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
          />
          <div
            onClick={() => fileInputRef.current?.click()}
            className="absolute inset-0 bg-slate-900/60 rounded-inherit opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer text-white"
            title="Upload student photo"
          >
            <Camera className="w-4 h-4" />
          </div>

          {student.photoUrl && onPhotoChange && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onPhotoChange(undefined);
              }}
              className="absolute -top-1 -right-1 p-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-xs"
              title="Remove photo"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          )}
        </>
      )}
    </div>
  );
};
