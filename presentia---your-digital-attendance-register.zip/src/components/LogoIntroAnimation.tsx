import React, { useState, useEffect, useRef } from 'react';
import { playSound } from '../utils/audio';
import { Volume2, VolumeX } from 'lucide-react';

interface LogoIntroAnimationProps {
  onComplete: () => void;
  soundEnabled?: boolean;
  onToggleSound?: () => void;
  autoCloseDelayMs?: number;
}

type AnimationStage = 
  | 'glass_enter'     // 0: Full-screen tempered glass plane with reflections & standoffs
  | 'tick_approach'   // 1: Mach-3 kinetic projectile incoming with plasma trail
  | 'hard_impact'     // 2: Hard collision, full-screen whiteout flash, full-screen radial fracture
  | 'shards_fly'      // 3: 3D canvas physics glass explosion & sparks across entire screen
  | 'shield_lock'     // 4: Official 3D shield & emblem magnetic lock
  | 'title_reveal'    // 5: Laser etch: PRESENTIA - YOUR DIGITAL ATTENDANCE REGISTER
  | 'settled';        // 6: Ready state

// 3D Glass Particle Definition for Canvas Physics Engine
interface GlassShard3D {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  rotX: number;
  rotY: number;
  rotZ: number;
  vRotX: number;
  vRotY: number;
  vRotZ: number;
  vertices: { x: number; y: number }[];
  size: number;
  hue: number;
  alpha: number;
  thickness: number;
}

interface SparkParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

// Sculpted 3D Beveled Checkmark modeled precisely from the user's uploaded logo
// Exact color: Cyan highlight #38bdf8 -> Electric Blue #0091ff -> Core Cobalt #0077d4 -> Shadow #024282
export const RealisticLogoCheckmark: React.FC<{
  size?: number;
  className?: string;
  glow?: boolean;
  gleam?: boolean;
}> = ({ size = 150, className = '', glow = true, gleam = true }) => {
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 160 160"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={glow ? 'filter drop-shadow-[0_0_30px_rgba(0,145,255,0.95)]' : ''}
      >
        <defs>
          {/* Main 3D Surface Gradient - Matches logo's electric cyan-to-azure sweep */}
          <linearGradient id="realLogoBody" x1="20" y1="20" x2="145" y2="135" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#38BDF8" />     {/* Bright Sky Cyan */}
            <stop offset="28%" stopColor="#00A3FF" />    {/* Electric Azure */}
            <stop offset="68%" stopColor="#0072CE" />    {/* Metallic Cobalt */}
            <stop offset="100%" stopColor="#024282" />   {/* Deep Navy Bevel Shadow */}
          </linearGradient>

          {/* Top Bevel Ridge Light Gradient (Sharp metallic edge catch) */}
          <linearGradient id="realLogoRidge" x1="25" y1="40" x2="145" y2="30" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="35%" stopColor="#BAE6FD" />
            <stop offset="70%" stopColor="#38BDF8" />
            <stop offset="100%" stopColor="#0091FF" />
          </linearGradient>

          {/* Underside Depth Extrusion */}
          <linearGradient id="realLogoUnder" x1="30" y1="100" x2="120" y2="140" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#023060" />
            <stop offset="50%" stopColor="#001F40" />
            <stop offset="100%" stopColor="#001024" />
          </linearGradient>

          {/* Specular Glint Reflection */}
          <linearGradient id="realLogoGlint" x1="15" y1="15" x2="150" y2="150" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.9" />
            <stop offset="25%" stopColor="#38BDF8" stopOpacity="0.5" />
            <stop offset="55%" stopColor="transparent" stopOpacity="0" />
          </linearGradient>

          <filter id="realBevelFilter" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="4" stdDeviation="5" floodColor="#001830" floodOpacity="0.7" />
          </filter>
        </defs>

        {/* Outer Kinetic Bloom Halo */}
        <circle cx="85" cy="80" r="58" fill="#00A3FF" opacity="0.25" className="blur-xl" />

        {/* 1. Realistic Deep 3D Underside Shadow Bevel (gives true physical volume) */}
        <path
          d="M24 88 C 36 78, 54 100, 68 118 C 88 80, 115 48, 144 32 C 148 35, 148 41, 143 47 C 112 74, 85 112, 68 128 C 52 128, 40 108, 24 88 Z"
          fill="url(#realLogoUnder)"
          filter="url(#realBevelFilter)"
        />

        {/* 2. Main Sculpted 3D Body - Aerodynamic swooping checkmark */}
        <path
          d="M20 80 C 34 68, 52 92, 66 112 C 86 72, 117 40, 146 24 C 150 22, 154 27, 148 33 C 117 66, 86 109, 68 125 C 50 125, 36 102, 20 80 Z"
          fill="url(#realLogoBody)"
        />

        {/* 3. Upper Bevel Edge (Highlights specular directional light) */}
        <path
          d="M21 78 C 35 66, 53 90, 66 110 C 86 70, 117 38, 146 22 C 148 23, 143 28, 137 32 C 110 50, 83 82, 66 113 C 53 98, 38 78, 21 78 Z"
          fill="url(#realLogoRidge)"
        />

        {/* 4. Center Spine Ridge Highlight */}
        <path
          d="M26 82 C 37 74, 52 94, 65 110 C 84 74, 113 46, 140 30"
          stroke="url(#realLogoGlint)"
          strokeWidth="3.2"
          strokeLinecap="round"
        />

        {/* 5. Crystalline Vertex Points */}
        <circle cx="146" cy="24" r="3.2" fill="#FFFFFF" />
        <circle cx="67" cy="112" r="3.2" fill="#BAE6FD" />
      </svg>

      {/* Dynamic light gleam across the tick */}
      {gleam && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-full">
          <div className="absolute -inset-full bg-gradient-to-r from-transparent via-white/40 to-transparent rotate-45 animate-[gleam_1.6s_infinite]" />
        </div>
      )}
    </div>
  );
};

export const LogoIntroAnimation: React.FC<LogoIntroAnimationProps> = ({
  onComplete,
  soundEnabled = true,
  onToggleSound,
  autoCloseDelayMs = 0,
}) => {
  const [stage, setStage] = useState<AnimationStage>('glass_enter');
  const [screenFlash, setScreenFlash] = useState(false);
  const [violentShake, setViolentShake] = useState(false);
  const [shockwaveRing, setShockwaveRing] = useState(false);
  const [projectileFlight, setProjectileFlight] = useState(false);
  const [titleGleam, setTitleGleam] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Initialize Canvas Full-Screen 3D Shatter Physics Simulation
  const startCanvasShatterPhysics = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = (canvas.width = window.innerWidth);
    const height = (canvas.height = window.innerHeight);
    const centerX = width / 2;
    const centerY = height / 2;

    // Generate 85 Realistic 3D Full-Screen Glass Shards
    const shards: GlassShard3D[] = [];
    const shardCount = 85;

    for (let i = 0; i < shardCount; i++) {
      const angle = (i / shardCount) * Math.PI * 2 + (Math.random() - 0.5) * 0.45;
      // High-velocity outward blast across full viewport width/height
      const speed = 320 + Math.random() * 650;
      const size = 18 + Math.random() * 55;

      const vCount = Math.random() > 0.35 ? 3 : 4;
      const vertices: { x: number; y: number }[] = [];
      for (let v = 0; v < vCount; v++) {
        const vAngle = (v / vCount) * Math.PI * 2 + (Math.random() - 0.5) * 0.6;
        const vDist = size * (0.5 + Math.random() * 0.7);
        vertices.push({
          x: Math.cos(vAngle) * vDist,
          y: Math.sin(vAngle) * vDist,
        });
      }

      shards.push({
        x: centerX + (Math.random() - 0.5) * 40,
        y: centerY + (Math.random() - 0.5) * 40,
        z: 0,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed * (height / width > 1 ? 1.2 : 0.85),
        vz: 140 + Math.random() * 450, // Explosively flying toward user's eyes
        rotX: Math.random() * Math.PI * 2,
        rotY: Math.random() * Math.PI * 2,
        rotZ: Math.random() * Math.PI * 2,
        vRotX: (Math.random() - 0.5) * 14,
        vRotY: (Math.random() - 0.5) * 16,
        vRotZ: (Math.random() - 0.5) * 12,
        vertices,
        size,
        hue: 195 + Math.random() * 20, // Cyan-azure glass tint
        alpha: 0.95,
        thickness: 2.5 + Math.random() * 3.5,
      });
    }

    // Generate 70 Kinetic Full-Screen Impact Sparks
    const sparks: SparkParticle[] = [];
    const sparkColors = ['#FFFFFF', '#BAE6FD', '#38BDF8', '#00A3FF', '#FDE047'];
    for (let i = 0; i < 70; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 220 + Math.random() * 600;
      sparks.push({
        x: centerX,
        y: centerY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 0,
        maxLife: 22 + Math.random() * 28,
        color: sparkColors[Math.floor(Math.random() * sparkColors.length)],
        size: 2 + Math.random() * 3.5,
      });
    }

    let lastTime = performance.now();

    const renderLoop = (now: number) => {
      const dt = Math.min((now - lastTime) / 1000, 0.035);
      lastTime = now;

      ctx.clearRect(0, 0, width, height);

      // 1. Draw Kinetic Sparks
      for (let i = sparks.length - 1; i >= 0; i--) {
        const p = sparks[i];
        p.life++;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vy += 190 * dt; // gravity
        p.vx *= 0.98; // air drag
        p.vy *= 0.98;

        const progress = p.life / p.maxLife;
        if (progress >= 1) {
          sparks.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.fillStyle = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 10;
        ctx.globalAlpha = 1 - progress;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (1 - progress * 0.5), 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // 2. Draw 3D Tempered Glass Shards with realistic lighting & specular facets
      const fov = 650;
      for (let i = 0; i < shards.length; i++) {
        const s = shards[i];
        s.x += s.vx * dt;
        s.y += s.vy * dt;
        s.z += s.vz * dt;
        s.vy += 220 * dt;
        s.rotX += s.vRotX * dt;
        s.rotY += s.vRotY * dt;
        s.rotZ += s.vRotZ * dt;

        const scale = fov / (fov + s.z * 0.5);
        if (scale <= 0) continue;

        const projX = s.x;
        const projY = s.y;

        ctx.save();
        ctx.translate(projX, projY);
        ctx.rotate(s.rotZ);

        const glint = Math.abs(Math.sin(s.rotX) * Math.cos(s.rotY));
        const isGlinting = glint > 0.88;

        const glassAlpha = Math.max(0, s.alpha * (1 - s.z / 2200));
        ctx.globalAlpha = glassAlpha;

        ctx.beginPath();
        for (let v = 0; v < s.vertices.length; v++) {
          const vx = s.vertices[v].x * scale;
          const vy = s.vertices[v].y * scale * Math.cos(s.rotX);
          if (v === 0) ctx.moveTo(vx, vy);
          else ctx.lineTo(vx, vy);
        }
        ctx.closePath();

        const grad = ctx.createLinearGradient(-s.size, -s.size, s.size, s.size);
        grad.addColorStop(0, `hsla(${s.hue}, 28%, 32%, ${0.75 + glint * 0.25})`);
        grad.addColorStop(0.5, `hsla(${s.hue}, 34%, 18%, ${0.65 + glint * 0.25})`);
        grad.addColorStop(1, `hsla(${s.hue}, 40%, 10%, ${0.55 + glint * 0.2})`);

        ctx.fillStyle = grad;
        ctx.fill();

        ctx.strokeStyle = isGlinting
          ? 'rgba(255, 255, 255, 0.95)'
          : `rgba(56, 189, 248, ${0.55 + glint * 0.4})`;
        ctx.lineWidth = Math.max(1, s.thickness * scale * 0.65);
        ctx.shadowColor = 'rgba(0, 163, 255, 0.85)';
        ctx.shadowBlur = isGlinting ? 18 : 6;
        ctx.stroke();

        if (isGlinting && Math.random() > 0.4) {
          ctx.strokeStyle = '#FFFFFF';
          ctx.lineWidth = 1.8;
          ctx.beginPath();
          ctx.moveTo(-8 * scale, 0);
          ctx.lineTo(8 * scale, 0);
          ctx.moveTo(0, -8 * scale);
          ctx.lineTo(0, 8 * scale);
          ctx.stroke();
        }

        ctx.restore();
      }

      if (shards.length > 0) {
        animationFrameRef.current = requestAnimationFrame(renderLoop);
      }
    };

    animationFrameRef.current = requestAnimationFrame(renderLoop);
  };

  // Fast & Furious Pacing (~ 1.6 - 1.8s sequence)
  const runSequence = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
    }

    setStage('glass_enter');
    setScreenFlash(false);
    setViolentShake(false);
    setShockwaveRing(false);
    setProjectileFlight(false);
    setTitleGleam(false);
    setIsExiting(false);

    playSound('ambient', soundEnabled);

    // T+100ms: Kinetic projectile dives from deep space
    const t1 = setTimeout(() => {
      setProjectileFlight(true);
      playSound('whoosh', soundEnabled);
      setStage('tick_approach');
    }, 100);

    // T+340ms: HARD KINETIC IMPACT & FULL-SCREEN EXPLOSIVE GLASS BLAST
    const t2 = setTimeout(() => {
      setStage('hard_impact');
      setScreenFlash(true);      // 50ms blinding whiteout across whole screen
      setViolentShake(true);     // High amplitude camera shake
      setShockwaveRing(true);
      playSound('shatter', soundEnabled);
      startCanvasShatterPhysics();
    }, 340);

    // T+400ms: Flash cuts out, glass shards rocket to screen edges
    const t3 = setTimeout(() => {
      setScreenFlash(false);
      setStage('shards_fly');
    }, 400);

    // T+620ms: Recoil camera stabilizes
    const t4 = setTimeout(() => {
      setViolentShake(false);
    }, 620);

    // T+720ms: 3D Shield and Official Presentia Logo snaps into magnetic lock
    const t5 = setTimeout(() => {
      setStage('shield_lock');
      playSound('lock', soundEnabled);
    }, 720);

    // T+1000ms: Laser etch reveals official logo
    const t6 = setTimeout(() => {
      setStage('title_reveal');
      setTitleGleam(true);
      playSound('complete', soundEnabled);
    }, 1000);

    // T+1400ms: Settled full-screen logo display
    const t7 = setTimeout(() => {
      setStage('settled');
    }, 1400);

    // T+2000ms: Smoothly initiate exit
    const t8 = setTimeout(() => {
      setIsExiting(true);
    }, 2000);

    // T+2300ms: Automatically open the interface just after the animation
    const t9 = setTimeout(() => {
      onComplete();
    }, 2300);

    return [t1, t2, t3, t4, t5, t6, t7, t8, t9];
  };

  useEffect(() => {
    const timers = runSequence();
    return () => {
      timers.forEach(clearTimeout);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [soundEnabled]);

  return (
    <div
      onClick={onComplete}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#02050e] text-white select-none overflow-hidden transition-opacity duration-300 ${
        isExiting ? 'opacity-0 pointer-events-none' : 'opacity-100'
      } ${
        violentShake ? 'animate-[ff-camera-shake_0.22s_infinite]' : ''
      }`}
    >
      {/* Dynamic Keyframes for Full-Screen Hyper-Realistic Shatter */}
      <style>{`
        @keyframes ff-camera-shake {
          0% { transform: translate(0px, 0px) rotate(0deg); }
          20% { transform: translate(-14px, 10px) rotate(-1.8deg); }
          40% { transform: translate(16px, -12px) rotate(2deg); }
          60% { transform: translate(-12px, -8px) rotate(-1.2deg); }
          80% { transform: translate(14px, 12px) rotate(1.4deg); }
          100% { transform: translate(0px, 0px) rotate(0deg); }
        }
        @keyframes ff-supersonic-dive {
          0% {
            transform: translate3d(600px, -600px, 0) scale(0.06) rotate(-45deg);
            opacity: 0;
            filter: blur(14px) drop-shadow(0 0 50px #00A3FF);
          }
          65% {
            transform: translate3d(160px, -160px, 0) scale(0.65) rotate(-20deg);
            opacity: 1;
            filter: blur(2px) drop-shadow(0 0 35px #38BDF8);
          }
          100% {
            transform: translate3d(0, 0, 0) scale(1) rotate(0deg);
            opacity: 1;
            filter: blur(0px) drop-shadow(0 0 30px #00A3FF);
          }
        }
        @keyframes ff-fullscreen-shimmer {
          0% { transform: translateX(-120%) rotate(25deg); }
          100% { transform: translateX(220%) rotate(25deg); }
        }
        @keyframes ff-fullscreen-shock {
          0% { transform: scale(0.05); opacity: 1; border-width: 10px; }
          60% { opacity: 0.95; }
          100% { transform: scale(6); opacity: 0; border-width: 1px; }
        }
        @keyframes ff-laser-etch {
          0% { transform: scaleX(0); opacity: 0; }
          40% { transform: scaleX(1); opacity: 1; }
          100% { transform: scaleX(1); opacity: 0.8; }
        }
      `}</style>

      {/* Fullscreen HTML5 Physics Canvas for 3D Shards & Sparks */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none z-30 w-full h-full"
      />

      {/* Full-Screen Whiteout Flash (50ms intense optical impact) */}
      {screenFlash && (
        <div className="absolute inset-0 bg-white z-40 pointer-events-none transition-opacity duration-75" />
      )}

      {/* Atmospheric Space Gradients & Energy Nebulae */}
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(#38bdf8_1.5px,transparent_1.5px)] [background-size:24px_24px]" />
      <div className="absolute top-1/4 left-1/4 w-[650px] h-[650px] bg-[#0091FF]/15 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-[#0284C7]/20 rounded-full blur-[130px] pointer-events-none" />

      {/* 1. FULL-SCREEN SMOKY TEMPERED STEALTH GLASS SHEET (Stages: glass_enter & tick_approach) */}
      {(stage === 'glass_enter' || stage === 'tick_approach') && (
        <div
          className="absolute inset-0 z-10 transition-all duration-300 pointer-events-none"
          style={{
            background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.78) 0%, rgba(30, 41, 59, 0.6) 50%, rgba(15, 23, 42, 0.85) 100%)',
            backdropFilter: 'blur(10px)',
          }}
        >
          {/* Pure Full-Screen Glass Perimeter Refraction & Dark Specular Edge */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              border: '1px solid rgba(148, 163, 184, 0.45)',
              boxShadow: `
                inset 0 0 120px rgba(0, 0, 0, 0.8),
                inset 0 0 180px rgba(56, 189, 248, 0.12),
                0 0 60px rgba(0, 163, 255, 0.3)
              `,
            }}
          />

          {/* Full-Screen Diagonal Specular Glare Sweeping Across Smoky Glass */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -inset-full w-[300%] h-[300%] bg-gradient-to-r from-transparent via-cyan-300/15 to-transparent rotate-25 animate-[ff-fullscreen-shimmer_1.8s_infinite]" />
          </div>

          {/* Full-Screen High-Tech Optical Targeting Center Reticle */}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <div className="relative w-48 h-48 sm:w-60 sm:h-60 flex items-center justify-center opacity-70">
              <div className="w-full h-full border border-dashed border-sky-400/70 rounded-full animate-spin [animation-duration:12s]" />
              <div className="absolute w-28 h-28 sm:w-36 sm:h-36 border-2 border-sky-400/80 rounded-full shadow-[0_0_25px_#00A3FF]" />
              <div className="absolute w-4 h-4 bg-sky-300 rounded-full animate-ping" />
              {/* Full-width and full-height crosshair coordinate lines */}
              <div className="absolute w-screen h-[1px] bg-gradient-to-r from-transparent via-sky-400/50 to-transparent" />
              <div className="absolute h-screen w-[1px] bg-gradient-to-b from-transparent via-sky-400/50 to-transparent" />
            </div>
          </div>
        </div>
      )}

      {/* Subtle Floating Sound Toggle (Top Right) */}
      {onToggleSound && (
        <div className="absolute top-5 right-5 z-40">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleSound();
            }}
            className="p-2.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-slate-700/60 text-slate-300 hover:text-white hover:border-sky-400 transition-colors shadow-lg"
            title={soundEnabled ? 'Mute' : 'Enable Sound'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-sky-400" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>
      )}

      {/* Center 3D Stage Viewport */}
      <div className="relative flex-1 w-full h-full flex items-center justify-center perspective-[1200px] z-20">
        {/* Full-Screen Expanding Optical Shockwave */}
        {shockwaveRing && (
          <div className="absolute w-64 h-64 rounded-full border-4 border-[#38BDF8] animate-[ff-fullscreen-shock_0.45s_cubic-bezier(0,0,0.2,1)_forwards] pointer-events-none shadow-[0_0_60px_#00A3FF]" />
        )}

        {/* 2. THE MACH-3 KINETIC PROJECTILE INCOMING (Supersonic Strike) */}
        {stage === 'tick_approach' && projectileFlight && (
          <div className="absolute z-35 pointer-events-none animate-[ff-supersonic-dive_0.24s_cubic-bezier(0.1,0.9,0.2,1)_forwards]">
            {/* Blue Plasma Trail */}
            <div className="absolute -top-20 -right-20 w-44 h-2.5 bg-gradient-to-r from-transparent via-[#38BDF8] to-white -rotate-45 blur-sm" />
            <RealisticLogoCheckmark size={170} glow={true} gleam={true} />
          </div>
        )}

        {/* 3. FULL-SCREEN HARD COLLISION & RADIAL CRACK NETWORK (Stage: hard_impact) */}
        {(stage === 'hard_impact' || stage === 'shards_fly') && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-25 overflow-hidden">
            {/* Full-Screen Massive Dark Glass Fracture Web Spanning the Entire Display */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none"
              preserveAspectRatio="none"
              viewBox="-500 -500 1000 1000"
            >
              <g stroke="rgba(148, 163, 184, 0.95)" strokeWidth="3" fill="none">
                {/* 20 Giant Radial Fissures Reaching All 4 Screen Corners & Borders */}
                <path d="M0,0 L-480,-480" strokeWidth="4" stroke="#38BDF8" />
                <path d="M0,0 L480,-480" strokeWidth="4" stroke="#38BDF8" />
                <path d="M0,0 L-480,480" strokeWidth="4" stroke="#38BDF8" />
                <path d="M0,0 L480,480" strokeWidth="4" stroke="#38BDF8" />

                <path d="M0,0 L-500,-250" strokeWidth="3" />
                <path d="M0,0 L-250,-500" strokeWidth="3" />
                <path d="M0,0 L0,-500" strokeWidth="3.5" stroke="#38BDF8" />
                <path d="M0,0 L250,-500" strokeWidth="3" />
                <path d="M0,0 L500,-250" strokeWidth="3" />
                <path d="M0,0 L500,0" strokeWidth="3.5" stroke="#38BDF8" />
                <path d="M0,0 L500,250" strokeWidth="3" />
                <path d="M0,0 L250,500" strokeWidth="3" />
                <path d="M0,0 L0,500" strokeWidth="3.5" stroke="#38BDF8" />
                <path d="M0,0 L-250,500" strokeWidth="3" />
                <path d="M0,0 L-500,250" strokeWidth="3" />
                <path d="M0,0 L-500,0" strokeWidth="3.5" stroke="#38BDF8" />

                {/* Concentric Full-Screen Spiderweb Shock Rings */}
                <path
                  d="M-80,-60 L-30,-120 L70,-90 L120,20 L70,110 L-60,90 Z"
                  strokeWidth="2.5"
                  stroke="#38BDF8"
                />
                <path
                  d="M-180,-140 L-80,-260 L160,-200 L260,40 L160,240 L-140,200 Z"
                  strokeWidth="2.2"
                  stroke="rgba(148, 163, 184, 0.85)"
                />
                <path
                  d="M-300,-220 L-140,-420 L280,-320 L440,60 L280,380 L-240,320 Z"
                  strokeWidth="1.8"
                  stroke="#38BDF8"
                />
                <path
                  d="M-420,-320 L-200,-480 L400,-440 L490,90 L390,460 L-340,440 Z"
                  strokeWidth="1.2"
                  stroke="rgba(56,189,248,0.7)"
                />
              </g>
            </svg>

            {/* Kinetic Blue Tick Embedded at the Center of the Shattered Screen */}
            <div className="relative z-30 scale-125 filter drop-shadow-[0_0_40px_#00A3FF]">
              <RealisticLogoCheckmark size={160} glow={true} gleam={false} />
            </div>
          </div>
        )}

        {/* 4. FULL-SCREEN OFFICIAL DARK LOGO REVEAL (Stages: shield_lock, title_reveal, settled) */}
        {(stage === 'shield_lock' || stage === 'title_reveal' || stage === 'settled') && (
          <div
            onClick={onComplete}
            className="absolute inset-0 flex items-center justify-center p-4 sm:p-8 cursor-pointer transition-all duration-300 transform scale-100 animate-[fadeIn_0.35s_cubic-bezier(0.16,1,0.3,1)] z-25"
          >
            {/* Surrounding Electric Cyan Shock Aura */}
            <div className="absolute w-[85vw] max-w-5xl h-[75vh] bg-gradient-to-r from-[#00A3FF]/25 via-[#38BDF8]/35 to-[#0284C7]/25 rounded-3xl blur-3xl pointer-events-none animate-pulse" />

            {/* Genuine Full-Screen Official Dark Logo */}
            <div className="relative max-w-5xl w-full max-h-[85vh] flex items-center justify-center rounded-3xl overflow-hidden border-2 border-sky-400/80 bg-slate-950/95 shadow-[0_25px_100px_rgba(0,163,255,0.65)] group">
              <img
                src="/assets/presentia_dark_logo.jpg"
                alt="Presentia Logo"
                className="w-full h-auto max-h-[82vh] object-contain rounded-3xl transition-transform duration-500 group-hover:scale-[1.01]"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/assets/presentia_logo.jpg';
                }}
              />

              {/* Laser scan line passing over image on reveal */}
              {stage === 'title_reveal' && (
                <div className="absolute inset-y-0 w-8 bg-gradient-to-r from-transparent via-cyan-300 to-transparent shadow-[0_0_35px_#38BDF8] pointer-events-none animate-[ff-laser-etch_0.5s_ease-out_forwards]" />
              )}

              {/* Glass reflection sheen */}
              <div className="absolute inset-0 bg-gradient-to-tr from-sky-400/10 via-transparent to-white/15 pointer-events-none" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
