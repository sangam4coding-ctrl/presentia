import React, { useState } from 'react';
import { Student } from '../types/attendance';
import { Sparkles, X, Shuffle, UserCheck } from 'lucide-react';
import { playSound } from '../utils/audio';

interface RandomPickerModalProps {
  students: Student[];
  onClose: () => void;
  soundEnabled: boolean;
}

export const RandomPickerModal: React.FC<RandomPickerModalProps> = ({
  students,
  onClose,
  soundEnabled,
}) => {
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);

  const pickRandom = () => {
    if (students.length === 0) return;
    setIsSpinning(true);
    playSound('click', soundEnabled);

    let counter = 0;
    const interval = setInterval(() => {
      const randIdx = Math.floor(Math.random() * students.length);
      setSelectedStudent(students[randIdx]);
      playSound('click', soundEnabled);
      counter++;
      if (counter > 14) {
        clearInterval(interval);
        const finalIdx = Math.floor(Math.random() * students.length);
        setSelectedStudent(students[finalIdx]);
        setIsSpinning(false);
        playSound('complete', soundEnabled);
      }
    }, 90);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md p-6 text-center">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-2 text-emerald-600">
            <Sparkles className="w-5 h-5" />
            <h3 className="font-bold text-slate-900 text-sm">Random Student Selector</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-slate-500 mb-6">
          Use this interactive selector to call on students for attendance confirmation, answers, or classroom activities.
        </p>

        <div className="p-8 rounded-2xl bg-gradient-to-b from-slate-50 to-slate-100 border border-slate-200 min-h-[180px] flex flex-col items-center justify-center mb-6">
          {selectedStudent ? (
            <div className={`transition-all duration-150 ${isSpinning ? 'scale-90 opacity-70' : 'scale-100 opacity-100'}`}>
              <div
                className="w-16 h-16 mx-auto rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-md mb-3"
                style={{ backgroundColor: selectedStudent.avatarColor }}
              >
                {selectedStudent.name
                  .split(' ')
                  .map((n) => n[0])
                  .slice(0, 2)
                  .join('')}
              </div>
              <h2 className="text-lg font-bold text-slate-900">{selectedStudent.name}</h2>
              <span className="font-mono text-xs text-slate-500 mt-0.5 block">
                Roll No: {selectedStudent.rollNo}
              </span>
            </div>
          ) : (
            <div className="text-slate-400">
              <UserCheck className="w-12 h-12 mx-auto mb-2 opacity-50 text-slate-400" />
              <p className="text-xs font-medium">Click Shuffle to pick a student</p>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3">
          <button
            disabled={isSpinning}
            onClick={pickRandom}
            className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-semibold text-xs shadow-md flex items-center justify-center gap-2 transition-all disabled:opacity-50"
          >
            <Shuffle className={`w-4 h-4 ${isSpinning ? 'animate-spin' : ''}`} />
            <span>{isSpinning ? 'Selecting...' : selectedStudent ? 'Pick Another' : 'Roll & Select Student'}</span>
          </button>
          <button
            onClick={onClose}
            className="py-2.5 px-4 rounded-xl border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
