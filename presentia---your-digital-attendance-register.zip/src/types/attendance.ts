export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused';

export interface Student {
  id: string;
  rollNo: string;
  name: string;
  gender: 'male' | 'female' | 'other';
  avatarColor: string;
  photoUrl?: string; // Base64 data URL or photo URL
  guardianName: string;
  guardianPhone: string;
  guardianEmail: string;
  notes?: string;
  seatRow?: number;
  seatCol?: number;
}

export interface AttendanceRecord {
  studentId: string;
  status: AttendanceStatus;
  timestamp: string;
  note?: string;
}

export interface SessionAttendance {
  id: string; // e.g., classId_YYYY-MM-DD_period
  classId: string;
  date: string; // YYYY-MM-DD
  period: string; // e.g., "Morning Session", "Period 1", "Period 2"
  records: Record<string, AttendanceRecord>;
  takenBy: string;
  notes?: string;
  lastUpdated: string;
}

export interface Classroom {
  id: string;
  name: string;
  code: string;
  subject: string;
  room: string;
  teacher: string;
  academicYear: string;
  periods: string[];
  students: Student[];
}

export type ViewTab = 'mark' | 'history' | 'analytics' | 'reports' | 'classes';
