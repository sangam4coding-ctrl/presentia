import { Classroom, SessionAttendance, Student, AttendanceStatus } from '../types/attendance';
import { INITIAL_CLASSES, generateSeedSessions } from './mockData';

const STORAGE_KEY_CLASSES = 'presentia_classes_v1';
const STORAGE_KEY_SESSIONS = 'presentia_sessions_v1';
const STORAGE_KEY_SETTINGS = 'presentia_settings_v1';

export interface AppSettings {
  soundEnabled: boolean;
  lateThresholdPercent: number; // e.g. 75%
  schoolName: string;
  logoStyle?: 'official' | 'monogram' | 'shield' | 'folio';
}

export const DEFAULT_SETTINGS: AppSettings = {
  soundEnabled: true,
  lateThresholdPercent: 75,
  schoolName: 'St. Peter\'s International Academy',
  logoStyle: 'official',
};

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      logoStyle: parsed.logoStyle && parsed.logoStyle !== 'monogram' ? parsed.logoStyle : 'official',
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings', e);
  }
}

export function loadClasses(): Classroom[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CLASSES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_CLASSES, JSON.stringify(INITIAL_CLASSES));
      return INITIAL_CLASSES;
    }
    const parsed = JSON.parse(raw);
    return parsed.length > 0 ? parsed : INITIAL_CLASSES;
  } catch {
    return INITIAL_CLASSES;
  }
}

export function saveClasses(classes: Classroom[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_CLASSES, JSON.stringify(classes));
  } catch (e) {
    console.error('Failed to save classes', e);
  }
}

export function loadSessions(classes: Classroom[] = INITIAL_CLASSES): SessionAttendance[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SESSIONS);
    if (!raw) {
      const seeded = generateSeedSessions(classes);
      localStorage.setItem(STORAGE_KEY_SESSIONS, JSON.stringify(seeded));
      return seeded;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      const seeded = generateSeedSessions(classes);
      localStorage.setItem(STORAGE_KEY_SESSIONS, JSON.stringify(seeded));
      return seeded;
    }
    return parsed;
  } catch {
    return generateSeedSessions(classes);
  }
}

export function saveSession(session: SessionAttendance): SessionAttendance[] {
  try {
    const currentSessions = loadSessions();
    const existingIdx = currentSessions.findIndex(
      (s) => s.id === session.id || (s.classId === session.classId && s.date === session.date && s.period === session.period)
    );

    let updated: SessionAttendance[];
    if (existingIdx >= 0) {
      updated = [...currentSessions];
      updated[existingIdx] = { ...session, lastUpdated: new Date().toISOString() };
    } else {
      updated = [session, ...currentSessions];
    }

    localStorage.setItem(STORAGE_KEY_SESSIONS, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Failed to save session', e);
    return loadSessions();
  }
}

export function deleteSession(sessionId: string): SessionAttendance[] {
  try {
    const currentSessions = loadSessions();
    const filtered = currentSessions.filter((s) => s.id !== sessionId);
    localStorage.setItem(STORAGE_KEY_SESSIONS, JSON.stringify(filtered));
    return filtered;
  } catch {
    return loadSessions();
  }
}

export function resetAllData(): { classes: Classroom[]; sessions: SessionAttendance[] } {
  localStorage.removeItem(STORAGE_KEY_CLASSES);
  localStorage.removeItem(STORAGE_KEY_SESSIONS);
  const classes = INITIAL_CLASSES;
  const sessions = generateSeedSessions(classes);
  localStorage.setItem(STORAGE_KEY_CLASSES, JSON.stringify(classes));
  localStorage.setItem(STORAGE_KEY_SESSIONS, JSON.stringify(sessions));
  return { classes, sessions };
}

// Student Analytics Calculator
export interface StudentStats {
  student: Student;
  totalSessions: number;
  presentCount: number;
  absentCount: number;
  lateCount: number;
  excusedCount: number;
  attendanceRate: number; // 0 - 100
  streak: number; // Current consecutive present sessions
  isAtRisk: boolean;
  recentLogs: Array<{
    date: string;
    period: string;
    status: AttendanceStatus;
    note?: string;
  }>;
}

export function calculateStudentStats(
  student: Student,
  classId: string,
  sessions: SessionAttendance[],
  riskThreshold = 75
): StudentStats {
  const classSessions = sessions
    .filter((s) => s.classId === classId && s.records[student.id])
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  let presentCount = 0;
  let absentCount = 0;
  let lateCount = 0;
  let excusedCount = 0;
  let streak = 0;
  let streakActive = true;

  const recentLogs: StudentStats['recentLogs'] = [];

  classSessions.forEach((session) => {
    const rec = session.records[student.id];
    if (!rec) return;

    recentLogs.push({
      date: session.date,
      period: session.period,
      status: rec.status,
      note: rec.note,
    });

    if (rec.status === 'present') {
      presentCount++;
      if (streakActive) streak++;
    } else if (rec.status === 'late') {
      lateCount++;
      streakActive = false;
    } else if (rec.status === 'absent') {
      absentCount++;
      streakActive = false;
    } else if (rec.status === 'excused') {
      excusedCount++;
      // Excused doesn't break positive streak
    }
  });

  const totalSessions = classSessions.length;
  // Calculate attendance rate (Present counts 100%, Late counts 80% towards participation)
  const attendanceRate =
    totalSessions > 0
      ? Math.round(((presentCount + lateCount * 0.8) / Math.max(1, totalSessions - excusedCount)) * 100)
      : 100;

  const isAtRisk = attendanceRate < riskThreshold && totalSessions >= 3;

  return {
    student,
    totalSessions,
    presentCount,
    absentCount,
    lateCount,
    excusedCount,
    attendanceRate: Math.min(100, Math.max(0, attendanceRate)),
    streak,
    isAtRisk,
    recentLogs,
  };
}

// Classroom Summary Stats
export interface ClassSummaryStats {
  totalStudents: number;
  totalSessionsRecorded: number;
  averageAttendanceRate: number;
  totalAbsences: number;
  atRiskCount: number;
  perfectStreakCount: number; // streak >= 10
  dayOfWeekBreakdown: Record<string, { sessions: number; averageRate: number }>;
}

export function calculateClassSummary(
  classroom: Classroom,
  sessions: SessionAttendance[],
  riskThreshold = 75
): ClassSummaryStats {
  const classSessions = sessions.filter((s) => s.classId === classroom.id);
  const studentStats = classroom.students.map((st) =>
    calculateStudentStats(st, classroom.id, sessions, riskThreshold)
  );

  const totalStudents = classroom.students.length;
  const totalSessionsRecorded = classSessions.length;
  const atRiskCount = studentStats.filter((s) => s.isAtRisk).length;
  const perfectStreakCount = studentStats.filter((s) => s.streak >= 10).length;
  const totalAbsences = studentStats.reduce((sum, s) => sum + s.absentCount, 0);

  const averageAttendanceRate =
    studentStats.length > 0
      ? Math.round(studentStats.reduce((sum, s) => sum + s.attendanceRate, 0) / studentStats.length)
      : 0;

  // Day of week patterns
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayBuckets: Record<string, { totalRate: number; count: number }> = {
    Monday: { totalRate: 0, count: 0 },
    Tuesday: { totalRate: 0, count: 0 },
    Wednesday: { totalRate: 0, count: 0 },
    Thursday: { totalRate: 0, count: 0 },
    Friday: { totalRate: 0, count: 0 },
  };

  classSessions.forEach((session) => {
    const dayName = days[new Date(session.date).getDay()];
    if (dayBuckets[dayName]) {
      const recordsArr = Object.values(session.records);
      if (recordsArr.length > 0) {
        const presentLike = recordsArr.filter((r) => r.status === 'present' || r.status === 'late').length;
        const rate = Math.round((presentLike / recordsArr.length) * 100);
        dayBuckets[dayName].totalRate += rate;
        dayBuckets[dayName].count += 1;
      }
    }
  });

  const dayOfWeekBreakdown: Record<string, { sessions: number; averageRate: number }> = {};
  Object.keys(dayBuckets).forEach((d) => {
    const b = dayBuckets[d];
    dayOfWeekBreakdown[d] = {
      sessions: b.count,
      averageRate: b.count > 0 ? Math.round(b.totalRate / b.count) : 0,
    };
  });

  return {
    totalStudents,
    totalSessionsRecorded,
    averageAttendanceRate,
    totalAbsences,
    atRiskCount,
    perfectStreakCount,
    dayOfWeekBreakdown,
  };
}

// CSV Export Generator
export function generateAttendanceCSV(classroom: Classroom, sessions: SessionAttendance[]): string {
  const classSessions = sessions
    .filter((s) => s.classId === classroom.id)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const dates = classSessions.map((s) => `${s.date} (${s.period.slice(0, 8)})`);

  const headers = ['Roll No', 'Student Name', ...dates, 'Total Present', 'Total Absent', 'Total Late', 'Attendance %'];

  const rows = classroom.students.map((student) => {
    let presentCount = 0;
    let absentCount = 0;
    let lateCount = 0;

    const sessionMarks = classSessions.map((session) => {
      const rec = session.records[student.id];
      if (!rec) return '-';
      if (rec.status === 'present') {
        presentCount++;
        return 'P';
      }
      if (rec.status === 'absent') {
        absentCount++;
        return 'A';
      }
      if (rec.status === 'late') {
        lateCount++;
        return 'L';
      }
      if (rec.status === 'excused') {
        return 'E';
      }
      return '-';
    });

    const totalMarked = presentCount + absentCount + lateCount;
    const rate = totalMarked > 0 ? Math.round(((presentCount + lateCount * 0.8) / totalMarked) * 100) : 0;

    return [
      `"${student.rollNo}"`,
      `"${student.name}"`,
      ...sessionMarks.map((m) => `"${m}"`),
      presentCount,
      absentCount,
      lateCount,
      `"${rate}%"`,
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}
