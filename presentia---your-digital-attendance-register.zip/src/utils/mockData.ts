import { Classroom, SessionAttendance, Student, AttendanceStatus } from '../types/attendance';

const AVATAR_COLORS = [
  '#059669', // Emerald
  '#2563EB', // Royal Blue
  '#7C3AED', // Violet
  '#DB2777', // Rose
  '#D97706', // Amber
  '#0891B2', // Cyan
  '#4F46E5', // Indigo
  '#16A34A', // Green
];

export const INITIAL_CLASSES: Classroom[] = [
  {
    id: 'class_10a_physics',
    name: 'Grade 10 - Section A',
    code: 'G10-PHY',
    subject: 'Physics & Thermodynamics',
    room: 'Science Wing · Lab 204',
    teacher: 'Dr. Evelyn Carter',
    academicYear: '2026 - 2027',
    periods: ['Morning Roll Call', 'Period 1 · Mechanics', 'Period 4 · Lab Practicum'],
    students: [
      {
        id: 's1',
        rollNo: '10A-01',
        name: 'Alexander Wright',
        gender: 'male',
        avatarColor: '#2563EB',
        guardianName: 'Thomas Wright',
        guardianPhone: '+1 (555) 234-8901',
        guardianEmail: 't.wright@familymail.com',
        seatRow: 1,
        seatCol: 1,
      },
      {
        id: 's2',
        rollNo: '10A-02',
        name: 'Beatrix Vance',
        gender: 'female',
        avatarColor: '#7C3AED',
        guardianName: 'Miriam Vance',
        guardianPhone: '+1 (555) 489-1022',
        guardianEmail: 'm.vance@techcorp.io',
        seatRow: 1,
        seatCol: 2,
      },
      {
        id: 's3',
        rollNo: '10A-03',
        name: 'Carlos Mendez',
        gender: 'male',
        avatarColor: '#059669',
        guardianName: 'Elena Mendez',
        guardianPhone: '+1 (555) 301-7782',
        guardianEmail: 'elena.mendez@outlook.com',
        seatRow: 1,
        seatCol: 3,
      },
      {
        id: 's4',
        rollNo: '10A-04',
        name: 'Daphne Sterling',
        gender: 'female',
        avatarColor: '#DB2777',
        guardianName: 'Gregory Sterling',
        guardianPhone: '+1 (555) 672-9903',
        guardianEmail: 'greg.sterling@globalnet.org',
        seatRow: 1,
        seatCol: 4,
      },
      {
        id: 's5',
        rollNo: '10A-05',
        name: 'Ethan Zhao',
        gender: 'male',
        avatarColor: '#0891B2',
        guardianName: 'Lina Zhao',
        guardianPhone: '+1 (555) 890-4411',
        guardianEmail: 'lina.zhao@biotechlabs.com',
        seatRow: 2,
        seatCol: 1,
      },
      {
        id: 's6',
        rollNo: '10A-06',
        name: 'Fiona Gallagher',
        gender: 'female',
        avatarColor: '#D97706',
        guardianName: 'Sean Gallagher',
        guardianPhone: '+1 (555) 124-7890',
        guardianEmail: 'sgallagher@irelandmail.com',
        seatRow: 2,
        seatCol: 2,
      },
      {
        id: 's7',
        rollNo: '10A-07',
        name: 'Gabriel Morales',
        gender: 'male',
        avatarColor: '#4F46E5',
        guardianName: 'Sofia Morales',
        guardianPhone: '+1 (555) 902-3341',
        guardianEmail: 'sofia.morales@cityhosp.org',
        seatRow: 2,
        seatCol: 3,
      },
      {
        id: 's8',
        rollNo: '10A-08',
        name: 'Hannah Abbott',
        gender: 'female',
        avatarColor: '#16A34A',
        guardianName: 'Robert Abbott',
        guardianPhone: '+1 (555) 431-8899',
        guardianEmail: 'r.abbott@craftwood.com',
        seatRow: 2,
        seatCol: 4,
      },
      {
        id: 's9',
        rollNo: '10A-09',
        name: 'Isaac Newton Campbell',
        gender: 'male',
        avatarColor: '#2563EB',
        guardianName: 'Arthur Campbell',
        guardianPhone: '+1 (555) 670-1288',
        guardianEmail: 'art.campbell@academics.edu',
        seatRow: 3,
        seatCol: 1,
      },
      {
        id: 's10',
        rollNo: '10A-10',
        name: 'Julia Chen',
        gender: 'female',
        avatarColor: '#7C3AED',
        guardianName: 'David Chen',
        guardianPhone: '+1 (555) 345-9012',
        guardianEmail: 'dchen@baycapital.com',
        seatRow: 3,
        seatCol: 2,
      },
      {
        id: 's11',
        rollNo: '10A-11',
        name: 'Kai Takahashi',
        gender: 'male',
        avatarColor: '#059669',
        guardianName: 'Kenji Takahashi',
        guardianPhone: '+1 (555) 781-6543',
        guardianEmail: 'kenji.takahashi@tokyofinance.jp',
        seatRow: 3,
        seatCol: 3,
      },
      {
        id: 's12',
        rollNo: '10A-12',
        name: 'Leila Farouk',
        gender: 'female',
        avatarColor: '#DB2777',
        guardianName: 'Amira Farouk',
        guardianPhone: '+1 (555) 923-4567',
        guardianEmail: 'amira.farouk@healthclinics.org',
        seatRow: 3,
        seatCol: 4,
      },
      {
        id: 's13',
        rollNo: '10A-13',
        name: 'Marcus Brody',
        gender: 'male',
        avatarColor: '#0891B2',
        guardianName: 'Helen Brody',
        guardianPhone: '+1 (555) 541-2390',
        guardianEmail: 'helen.brody@museumart.org',
        seatRow: 4,
        seatCol: 1,
      },
      {
        id: 's14',
        rollNo: '10A-14',
        name: 'Nadia Petrov',
        gender: 'female',
        avatarColor: '#D97706',
        guardianName: 'Victor Petrov',
        guardianPhone: '+1 (555) 876-1122',
        guardianEmail: 'vpetrov@aerospaceeng.com',
        seatRow: 4,
        seatCol: 2,
      },
      {
        id: 's15',
        rollNo: '10A-15',
        name: 'Oliver King',
        gender: 'male',
        avatarColor: '#4F46E5',
        guardianName: 'Clara King',
        guardianPhone: '+1 (555) 219-8734',
        guardianEmail: 'clara.king@metrolibrary.org',
        seatRow: 4,
        seatCol: 3,
      },
      {
        id: 's16',
        rollNo: '10A-16',
        name: 'Priya Sharma',
        gender: 'female',
        avatarColor: '#16A34A',
        guardianName: 'Rajesh Sharma',
        guardianPhone: '+1 (555) 654-9988',
        guardianEmail: 'rajesh.sharma@consulting.in',
        seatRow: 4,
        seatCol: 4,
      },
      {
        id: 's17',
        rollNo: '10A-17',
        name: 'Quinn Sullivan',
        gender: 'other',
        avatarColor: '#7C3AED',
        guardianName: 'Morgan Sullivan',
        guardianPhone: '+1 (555) 789-3210',
        guardianEmail: 'm.sullivan@greenenergy.co',
        seatRow: 5,
        seatCol: 1,
      },
      {
        id: 's18',
        rollNo: '10A-18',
        name: 'Riley O\'Connor',
        gender: 'male',
        avatarColor: '#059669',
        guardianName: 'Liam O\'Connor',
        guardianPhone: '+1 (555) 432-8765',
        guardianEmail: 'liam.oconnor@civicworks.gov',
        seatRow: 5,
        seatCol: 2,
      },
      {
        id: 's19',
        rollNo: '10A-19',
        name: 'Samantha Brooks',
        gender: 'female',
        avatarColor: '#DB2777',
        guardianName: 'Diane Brooks',
        guardianPhone: '+1 (555) 321-9870',
        guardianEmail: 'dbrooks@harborvet.com',
        seatRow: 5,
        seatCol: 3,
      },
      {
        id: 's20',
        rollNo: '10A-20',
        name: 'Tristan Cole',
        gender: 'male',
        avatarColor: '#2563EB',
        guardianName: 'Alan Cole',
        guardianPhone: '+1 (555) 908-1123',
        guardianEmail: 'alancole@logisticsintl.com',
        seatRow: 5,
        seatCol: 4,
      },
    ],
  },
  {
    id: 'class_11b_math',
    name: 'Grade 11 - Advanced Calculus',
    code: 'G11-CALC',
    subject: 'Pure & Applied Mathematics',
    room: 'Academic Hall · Room 312',
    teacher: 'Prof. Marcus Holloway',
    academicYear: '2026 - 2027',
    periods: ['Period 2 · Differential Equations', 'Period 5 · Problem Workshop'],
    students: [
      {
        id: 'm1',
        rollNo: '11B-01',
        name: 'Aiden Mitchell',
        gender: 'male',
        avatarColor: '#059669',
        guardianName: 'Sarah Mitchell',
        guardianPhone: '+1 (555) 111-2233',
        guardianEmail: 'sarah.m@mitchell.org',
      },
      {
        id: 'm2',
        rollNo: '11B-02',
        name: 'Chloe Bennett',
        gender: 'female',
        avatarColor: '#2563EB',
        guardianName: 'Paul Bennett',
        guardianPhone: '+1 (555) 222-3344',
        guardianEmail: 'paul.bennett@architects.com',
      },
      {
        id: 'm3',
        rollNo: '11B-03',
        name: 'Daniel Kim',
        gender: 'male',
        avatarColor: '#7C3AED',
        guardianName: 'Sunhee Kim',
        guardianPhone: '+1 (555) 333-4455',
        guardianEmail: 'sunhee.kim@biochem.net',
      },
      {
        id: 'm4',
        rollNo: '11B-04',
        name: 'Emily Watson',
        gender: 'female',
        avatarColor: '#DB2777',
        guardianName: 'James Watson',
        guardianPhone: '+1 (555) 444-5566',
        guardianEmail: 'j.watson@legalcounsel.com',
      },
      {
        id: 'm5',
        rollNo: '11B-05',
        name: 'Felix Vance',
        gender: 'male',
        avatarColor: '#D97706',
        guardianName: 'Laura Vance',
        guardianPhone: '+1 (555) 555-6677',
        guardianEmail: 'laura.vance@stategov.org',
      },
      {
        id: 'm6',
        rollNo: '11B-06',
        name: 'Grace Hopper Patel',
        gender: 'female',
        avatarColor: '#0891B2',
        guardianName: 'Sunil Patel',
        guardianPhone: '+1 (555) 666-7788',
        guardianEmail: 'spatel@cloudtech.io',
      },
      {
        id: 'm7',
        rollNo: '11B-07',
        name: 'Henry Rollins',
        gender: 'male',
        avatarColor: '#4F46E5',
        guardianName: 'Nancy Rollins',
        guardianPhone: '+1 (555) 777-8899',
        guardianEmail: 'n.rollins@publishing.com',
      },
      {
        id: 'm8',
        rollNo: '11B-08',
        name: 'Isla Morales',
        gender: 'female',
        avatarColor: '#16A34A',
        guardianName: 'Oscar Morales',
        guardianPhone: '+1 (555) 888-9900',
        guardianEmail: 'omorales@urbanplan.org',
      },
    ],
  },
  {
    id: 'class_9c_lit',
    name: 'Grade 9 - World Literature',
    code: 'G09-LIT',
    subject: 'Literature & Creative Writing',
    room: 'Humanities Hall · Room 105',
    teacher: 'Ms. Clara Oswald',
    academicYear: '2026 - 2027',
    periods: ['Period 3 · Modern Drama', 'Period 6 · Creative Essay Studio'],
    students: [
      {
        id: 'l1',
        rollNo: '09C-01',
        name: 'Adrian Sterling',
        gender: 'male',
        avatarColor: '#4F46E5',
        guardianName: 'Jonathan Sterling',
        guardianPhone: '+1 (555) 123-9876',
        guardianEmail: 'jon.sterling@newsdaily.com',
      },
      {
        id: 'l2',
        rollNo: '09C-02',
        name: 'Brianna Cooper',
        gender: 'female',
        avatarColor: '#DB2777',
        guardianName: 'Kelly Cooper',
        guardianPhone: '+1 (555) 234-8765',
        guardianEmail: 'kcooper@designgroup.com',
      },
      {
        id: 'l3',
        rollNo: '09C-03',
        name: 'Caleb Evans',
        gender: 'male',
        avatarColor: '#059669',
        guardianName: 'Martin Evans',
        guardianPhone: '+1 (555) 345-7654',
        guardianEmail: 'mevans@greenridge.org',
      },
      {
        id: 'l4',
        rollNo: '09C-04',
        name: 'Diana Rosslyn',
        gender: 'female',
        avatarColor: '#D97706',
        guardianName: 'Patricia Rosslyn',
        guardianPhone: '+1 (555) 456-6543',
        guardianEmail: 'prosslyn@firstbank.com',
      },
    ],
  },
];

// Helper to generate realistic historical session records for past 30 days
export function generateSeedSessions(classrooms: Classroom[]): SessionAttendance[] {
  const sessions: SessionAttendance[] = [];
  const today = new Date('2026-10-13T12:00:00Z');

  // Pre-seed for the main Grade 10-A Physics class
  const mainClass = classrooms[0];
  const students = mainClass.students;

  // Track each student's general attendance personality (some high, some occasional late, 1 at risk)
  // Student 4 (Daphne Sterling) will be the at-risk student (< 75%)
  // Student 13 (Marcus Brody) has occasional late arrival (bus route)
  // Student 1, 2, 10, 16 are near 100%

  for (let daysAgo = 28; daysAgo >= 0; daysAgo--) {
    const d = new Date(today);
    d.setDate(d.getDate() - daysAgo);
    const dayOfWeek = d.getDay(); // 0 is Sunday, 6 is Saturday

    // Only school weekdays (Mon - Fri)
    if (dayOfWeek === 0 || dayOfWeek === 6) continue;

    const dateStr = d.toISOString().split('T')[0];
    const period = 'Morning Roll Call';
    const sessionId = `${mainClass.id}_${dateStr}_${period.replace(/\s+/g, '_')}`;

    const records: Record<string, { studentId: string; status: AttendanceStatus; timestamp: string; note?: string }> = {};

    students.forEach((student, idx) => {
      let status: AttendanceStatus = 'present';
      let note: string | undefined = undefined;

      // Realistic random seed tied to student and day
      const pseudoRandom = Math.sin(idx * 77 + daysAgo * 31) * 10000;
      const val = pseudoRandom - Math.floor(pseudoRandom);

      if (student.rollNo === '10A-04') {
        // Daphne Sterling - At Risk student (~70% attendance)
        if (val < 0.28) {
          status = 'absent';
          note = val < 0.14 ? 'Unexcused absence' : 'Parent notified - migraine';
        } else if (val < 0.40) {
          status = 'late';
          note = 'Arrived 20 mins into period';
        }
      } else if (student.rollNo === '10A-13') {
        // Marcus Brody - Commute delay prone
        if (val < 0.20) {
          status = 'late';
          note = 'School bus 4A delay';
        } else if (val < 0.25) {
          status = 'absent';
          note = 'Family travel';
        }
      } else if (student.rollNo === '10A-18') {
        // Riley O'Connor - Athlete
        if (daysAgo === 5 || daysAgo === 19) {
          status = 'excused';
          note = 'Varsity Cross Country Championship';
        } else if (val < 0.08) {
          status = 'absent';
          note = 'Dental appointment';
        }
      } else {
        // General students (94% - 98% present)
        if (val < 0.04) {
          status = 'absent';
          note = val < 0.02 ? 'Mild fever - sick slip submitted' : 'Family obligation';
        } else if (val < 0.08) {
          status = 'late';
          note = 'Traffic congestion';
        }
      }

      records[student.id] = {
        studentId: student.id,
        status,
        timestamp: `${dateStr}T08:15:00.000Z`,
        note,
      };
    });

    sessions.push({
      id: sessionId,
      classId: mainClass.id,
      date: dateStr,
      period,
      records,
      takenBy: mainClass.teacher,
      notes: daysAgo === 0 ? 'Regular morning session' : undefined,
      lastUpdated: `${dateStr}T08:25:00.000Z`,
    });
  }

  return sessions;
}
